# Pet Industry — Complete Knowledge Master

**Package:** QD-KB-062-pet-industry-v2026.07.31  
**Arabic:** قطاع الحيوانات الأليفة  
**Status:** production draft; not SME/regulatory approved  
**Subcategories:** 4

> This is the human-audit view. Runtime must use atomic JSONL records, deterministic questions/rules and selective retrieval rather than loading this entire file into a prompt.


# 01. Veterinary clinics / العيادات البيطرية

**Aliases:** Veterinary clinics

## industry — Industry scope — Veterinary clinics

Veterinary clinics sits within Pet Industry and covers veterinary, grooming, boarding and pet-supply services where species, health, welfare, vaccination, licensed veterinary activity, product suitability and emergency procedures determine safe procurement. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Veterinary clinics","aliases_en":["Veterinary clinics"],"aliases_ar":["العيادات البيطرية"],"sequence":1}`

## industry — UAE procurement workflow — Veterinary clinics

A typical UAE procurement path for Veterinary clinics moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Veterinary clinics","aliases_en":["Veterinary clinics"],"aliases_ar":["العيادات البيطرية"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Veterinary clinics

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include veterinary facility, veterinarian, groomer, boarding operator, authorized importer, distributor. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Veterinary clinics","aliases_en":["Veterinary clinics"],"aliases_ar":["العيادات البيطرية"],"sequence":3}`

## industry — Scope boundaries and escalation — Veterinary clinics

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Veterinary clinics. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Veterinary clinics","aliases_en":["Veterinary clinics"],"aliases_ar":["العيادات البيطرية"],"sequence":4}`

## products_services — veterinary consultation

veterinary consultation is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"veterinary consultation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — diagnostic service

diagnostic service is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"diagnostic service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — vaccination

vaccination is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"vaccination","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — surgery/treatment

surgery/treatment is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"surgery/treatment","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet grooming

pet grooming is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet grooming","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — mobile grooming

mobile grooming is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"mobile grooming","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet boarding

pet boarding is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet boarding","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — day care

day care is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"day care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet transport

pet transport is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet transport","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet food

pet food is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet food","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — therapeutic diet

therapeutic diet is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"therapeutic diet","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet accessory

pet accessory is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet accessory","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medication/product

medication/product is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"medication/product","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — animal hygiene product

animal hygiene product is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"animal hygiene product","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — emergency veterinary support

emergency veterinary support is a product or service family relevant to Veterinary clinics. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"emergency veterinary support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — species/breed/age

Technical topic: species/breed/age. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"species/breed/age","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — animal identity and microchip

Technical topic: animal identity and microchip. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"animal identity and microchip","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — health history

Technical topic: health history. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"health history","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — vaccination status

Technical topic: vaccination status. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"vaccination status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — behaviour/temperament

Technical topic: behaviour/temperament. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"behaviour/temperament","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — licensed veterinary scope

Technical topic: licensed veterinary scope. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"licensed veterinary scope","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — diagnosis/treatment boundary

Technical topic: diagnosis/treatment boundary. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"diagnosis/treatment boundary","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — grooming requirements

Technical topic: grooming requirements. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"grooming requirements","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — boarding capacity and environment

Technical topic: boarding capacity and environment. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"boarding capacity and environment","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — infection control

Technical topic: infection control. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"infection control","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — feeding/diet/allergy

Technical topic: feeding/diet/allergy. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"feeding/diet/allergy","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — medication administration

Technical topic: medication administration. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"medication administration","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — welfare and handling

Technical topic: welfare and handling. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"welfare and handling","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — emergency plan

Technical topic: emergency plan. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"emergency plan","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — owner consent

Technical topic: owner consent. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"owner consent","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — product registration/expiry

Technical topic: product registration/expiry. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"product registration/expiry","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — records and privacy

Technical topic: records and privacy. For Veterinary clinics, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"records and privacy","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — licensed veterinary clinic

licensed veterinary clinic is a supplier-market role or example for Veterinary clinics; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed veterinary clinic","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed veterinarian

licensed veterinarian is a supplier-market role or example for Veterinary clinics; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed veterinarian","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — professional grooming provider

professional grooming provider is a supplier-market role or example for Veterinary clinics; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"professional grooming provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed boarding facility

licensed boarding facility is a supplier-market role or example for Veterinary clinics; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed boarding facility","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — authorized pet-food distributor

authorized pet-food distributor is a supplier-market role or example for Veterinary clinics; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"authorized pet-food distributor","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — pet-product supplier

pet-product supplier is a supplier-market role or example for Veterinary clinics; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"pet-product supplier","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — veterinary facility

Supplier type: veterinary facility. In Veterinary clinics, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"veterinary facility","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — veterinary facility

Eligibility gate 1 for a veterinary facility responding to Veterinary clinics: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"veterinary facility","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — veterinarian

Supplier type: veterinarian. In Veterinary clinics, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"veterinarian","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — veterinarian

Eligibility gate 2 for a veterinarian responding to Veterinary clinics: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"veterinarian","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — groomer

Supplier type: groomer. In Veterinary clinics, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"groomer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — groomer

Eligibility gate 3 for a groomer responding to Veterinary clinics: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"groomer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — boarding operator

Supplier type: boarding operator. In Veterinary clinics, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"boarding operator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — boarding operator

Eligibility gate 4 for a boarding operator responding to Veterinary clinics: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"boarding operator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — authorized importer

Supplier type: authorized importer. In Veterinary clinics, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"authorized importer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — authorized importer

Eligibility gate 5 for a authorized importer responding to Veterinary clinics: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"authorized importer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — distributor

Supplier type: distributor. In Veterinary clinics, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"distributor","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — distributor

Eligibility gate 6 for a distributor responding to Veterinary clinics: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"distributor","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — pet transport provider

Supplier type: pet transport provider. In Veterinary clinics, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"pet transport provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — pet transport provider

Eligibility gate 7 for a pet transport provider responding to Veterinary clinics: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"pet transport provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — emergency clinic

Supplier type: emergency clinic. In Veterinary clinics, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"emergency clinic","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — emergency clinic

Eligibility gate 8 for a emergency clinic responding to Veterinary clinics: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"emergency clinic","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — animal/service identity

Quotation requirement: animal/service identity. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"animal_service_identity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — health/vaccination

Quotation requirement: health/vaccination. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"health_vaccination","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — scope and exclusions

Quotation requirement: scope and exclusions. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"scope_and_exclusions","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — facility/licence

Quotation requirement: facility/licence. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"facility_licence","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — diet/medication

Quotation requirement: diet/medication. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"diet_medication","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — welfare/infection control

Quotation requirement: welfare/infection control. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"welfare_infection_control","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — dates/capacity

Quotation requirement: dates/capacity. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"dates_capacity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — emergency/consent

Quotation requirement: emergency/consent. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"emergency_consent","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — product traceability

Quotation requirement: product traceability. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"product_traceability","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — pricing/cancellation

Quotation requirement: pricing/cancellation. Every supplier response for Veterinary clinics should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"pricing_cancellation","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — animal record

Document: animal record. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"animal_record","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — vaccination certificate

Document: vaccination certificate. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"vaccination_certificate","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — microchip/passport record

Document: microchip/passport record. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"microchip_passport_record","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — medical history

Document: medical history. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"medical_history","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — veterinary prescription

Document: veterinary prescription. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"veterinary_prescription","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — owner consent

Document: owner consent. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"owner_consent","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — boarding/grooming form

Document: boarding/grooming form. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"boarding_grooming_form","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — feeding/medication schedule

Document: feeding/medication schedule. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"feeding_medication_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — facility licence

Document: facility licence. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"facility_licence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — infection-control procedure

Document: infection-control procedure. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"infection_control_procedure","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — emergency contact

Document: emergency contact. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"emergency_contact","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — product label/registration

Document: product label/registration. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"product_label_registration","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — batch/expiry record

Document: batch/expiry record. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"batch_expiry_record","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — service terms

Document: service terms. For Veterinary clinics, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"service_terms","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Veterinary, Animal Health and Animal Welfare Services

Source activation for Veterinary clinics: Veterinary, Animal Health and Animal Welfare Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify facility, professional, import, animal welfare and product requirements.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET
- Structured data: `{"source_id":"UAE-MOCCAE-VET","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/services.aspx","source_type":"government_veterinary_portal","live_verification":true}`

## uae_regulations — Agriculture, Food Security, Veterinary and Environmental Services

Source activation for Veterinary clinics: Agriculture, Food Security, Veterinary and Environmental Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify the current service, permit, registration, environmental and veterinary requirements.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE
- Structured data: `{"source_id":"UAE-MOCCAE","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/home.aspx","source_type":"government_environment_agriculture_portal","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Veterinary clinics: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Certificate of Conformity for Regulated Products

Source activation for Veterinary clinics: UAE Certificate of Conformity for Regulated Products (Ministry of Industry and Advanced Technology). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify whether the exact product is regulated and whether the certificate remains valid.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOIAT-CONFORMITY
- Structured data: `{"source_id":"UAE-MOIAT-CONFORMITY","publisher":"Ministry of Industry and Advanced Technology","url":"https://moiat.gov.ae/en/services/issue-conformity-certificates-for-regulated-products","source_type":"government_conformity_service","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Veterinary clinics: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Veterinary clinics: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Veterinary clinics: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Veterinary, Animal Health and Animal Welfare Services

Source activation for Veterinary clinics: Veterinary, Animal Health and Animal Welfare Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify facility, professional, import, animal welfare and product requirements.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET
- Structured data: `{"source_id":"UAE-MOCCAE-VET","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/services.aspx","source_type":"government_veterinary_portal","live_verification":true}`

## inquiry_qualification — Animal Identity

Ask: What animal species, breed, age, identity and service or product are involved? Arabic: يرجى توضيح animal identity بالنسبة إلى العيادات البيطرية. Reason: animal identity is required to make Veterinary clinics quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-domain_1","question_en":"What animal species, breed, age, identity and service or product are involved?","question_ar":"يرجى توضيح animal identity بالنسبة إلى العيادات البيطرية.","internal_label_en":"animal identity","internal_label_ar":"متطلب العيادات البيطرية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Health/Vaccination

Ask: What health history, vaccination, allergy, medication, behaviour and special-care needs apply? Arabic: يرجى توضيح health/vaccination بالنسبة إلى العيادات البيطرية. Reason: health/vaccination is required to make Veterinary clinics quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-domain_2","question_en":"What health history, vaccination, allergy, medication, behaviour and special-care needs apply?","question_ar":"يرجى توضيح health/vaccination بالنسبة إلى العيادات البيطرية.","internal_label_en":"health/vaccination","internal_label_ar":"متطلب العيادات البيطرية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Service Classification

Ask: Is the need veterinary diagnosis/treatment, grooming, boarding, transport, food or supplies? Arabic: يرجى توضيح service classification بالنسبة إلى العيادات البيطرية. Reason: service classification is required to make Veterinary clinics quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-domain_3","question_en":"Is the need veterinary diagnosis/treatment, grooming, boarding, transport, food or supplies?","question_ar":"يرجى توضيح service classification بالنسبة إلى العيادات البيطرية.","internal_label_en":"service classification","internal_label_ar":"متطلب العيادات البيطرية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Licence/Consent

Ask: Which licensed veterinary/facility scope and owner consent are required? Arabic: يرجى توضيح licence/consent بالنسبة إلى العيادات البيطرية. Reason: licence/consent is required to make Veterinary clinics quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-domain_4","question_en":"Which licensed veterinary/facility scope and owner consent are required?","question_ar":"يرجى توضيح licence/consent بالنسبة إلى العيادات البيطرية.","internal_label_en":"licence/consent","internal_label_ar":"متطلب العيادات البيطرية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Welfare/Care

Ask: What welfare, handling, infection-control, diet and medication procedures apply? Arabic: يرجى توضيح welfare/care بالنسبة إلى العيادات البيطرية. Reason: welfare/care is required to make Veterinary clinics quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-domain_5","question_en":"What welfare, handling, infection-control, diet and medication procedures apply?","question_ar":"يرجى توضيح welfare/care بالنسبة إلى العيادات البيطرية.","internal_label_en":"welfare/care","internal_label_ar":"متطلب العيادات البيطرية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Schedule/Emergency

Ask: What dates, boarding/grooming capacity, emergency and contingency arrangements are required? Arabic: يرجى توضيح schedule/emergency بالنسبة إلى العيادات البيطرية. Reason: schedule/emergency is required to make Veterinary clinics quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-domain_6","question_en":"What dates, boarding/grooming capacity, emergency and contingency arrangements are required?","question_ar":"يرجى توضيح schedule/emergency بالنسبة إلى العيادات البيطرية.","internal_label_en":"schedule/emergency","internal_label_ar":"متطلب العيادات البيطرية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Product/Commercial

Ask: What product registration, batch, expiry, pricing, cancellation and complaint terms apply? Arabic: يرجى توضيح product/commercial بالنسبة إلى العيادات البيطرية. Reason: product/commercial is required to make Veterinary clinics quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-domain_7","question_en":"What product registration, batch, expiry, pricing, cancellation and complaint terms apply?","question_ar":"يرجى توضيح product/commercial بالنسبة إلى العيادات البيطرية.","internal_label_en":"product/commercial","internal_label_ar":"متطلب العيادات البيطرية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Veterinary clinics quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Veterinary clinics quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Veterinary clinics quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Veterinary clinics quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Veterinary clinics quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Veterinary clinics quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Veterinary clinics quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Veterinary clinics quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Veterinary clinics quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Veterinary clinics quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Veterinary clinics quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Veterinary clinics quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Veterinary clinics quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Veterinary clinics quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Veterinary clinics quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Veterinary clinics quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Veterinary clinics quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Veterinary clinics quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Veterinary clinics quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Veterinary clinics quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Veterinary clinics quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Veterinary clinics quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-veterinary-clinics-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Veterinary clinics, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-veterinary-clinics-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-veterinary-clinics-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Veterinary clinics; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-veterinary-clinics-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Veterinary clinics; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-veterinary-clinics-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Veterinary clinics; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-veterinary-clinics-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Veterinary clinics; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-veterinary-clinics-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Veterinary clinics; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-veterinary-clinics-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Veterinary clinics: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-veterinary-clinics-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Veterinary clinics: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-veterinary-clinics-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Veterinary clinics: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-veterinary-clinics-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Veterinary clinics: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-veterinary-clinics-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Veterinary clinics: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-veterinary-clinics-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Veterinary clinics: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-veterinary-clinics-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Veterinary clinics: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-veterinary-clinics-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Veterinary clinics: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-veterinary-clinics-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Veterinary clinics: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-veterinary-clinics-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Veterinary clinics: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-veterinary-clinics-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — clinical complexity

Cost driver: clinical complexity. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"clinical complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — animal size/behaviour

Cost driver: animal size/behaviour. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"animal size/behaviour","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — boarding duration

Cost driver: boarding duration. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"boarding duration","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — special diet/medication

Cost driver: special diet/medication. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"special diet/medication","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — emergency coverage

Cost driver: emergency coverage. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"emergency coverage","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — product type and import status

Cost driver: product type and import status. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"product type and import status","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Veterinary clinics quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Veterinary clinics: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Veterinary clinics: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Veterinary clinics: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Veterinary clinics: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Veterinary clinics: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Veterinary clinics: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Veterinary clinics: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Veterinary clinics: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Veterinary clinics: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Veterinary clinics: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — unlicensed veterinary treatment

Risk: unlicensed veterinary treatment. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"unlicensed veterinary treatment","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — missing vaccination

Risk: missing vaccination. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"missing vaccination","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — animal escape/injury

Risk: animal escape/injury. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"animal escape/injury","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — infection outbreak

Risk: infection outbreak. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"infection outbreak","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — wrong food/medication

Risk: wrong food/medication. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"wrong food/medication","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — poor emergency response

Risk: poor emergency response. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"poor emergency response","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Veterinary clinics, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Veterinary clinics: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Veterinary clinics: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Veterinary clinics: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Veterinary clinics: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Veterinary clinics: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Veterinary clinics: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Veterinary clinics, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Veterinary clinics, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Veterinary clinics, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Veterinary clinics, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Veterinary clinics, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Veterinary clinics, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Veterinary clinics, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Veterinary clinics, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Veterinary clinics: vague public request. Input: I need help with Veterinary clinics but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-veterinary-clinics-01","input":{"message":"I need help with Veterinary clinics but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Veterinary clinics: minimum quote-ready request. Input: Customer requests Veterinary clinics and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-veterinary-clinics-02","input":{"message":"Customer requests Veterinary clinics and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Veterinary clinics: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-veterinary-clinics-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Veterinary clinics: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-veterinary-clinics-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Veterinary clinics: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-veterinary-clinics-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Veterinary clinics: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-veterinary-clinics-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Veterinary clinics: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-veterinary-clinics-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — microchip

English term: microchip. Arabic operational label: مصطلح microchip ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"microchip","term_ar":"مصطلح microchip ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — vaccination certificate

English term: vaccination certificate. Arabic operational label: مصطلح vaccination certificate ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"vaccination certificate","term_ar":"مصطلح vaccination certificate ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — veterinary prescription

English term: veterinary prescription. Arabic operational label: مصطلح veterinary prescription ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"veterinary prescription","term_ar":"مصطلح veterinary prescription ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — animal welfare

English term: animal welfare. Arabic operational label: مصطلح animal welfare ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"animal welfare","term_ar":"مصطلح animal welfare ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — boarding

English term: boarding. Arabic operational label: مصطلح boarding ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"boarding","term_ar":"مصطلح boarding ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — grooming

English term: grooming. Arabic operational label: مصطلح grooming ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"grooming","term_ar":"مصطلح grooming ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — infection control

English term: infection control. Arabic operational label: مصطلح infection control ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"infection control","term_ar":"مصطلح infection control ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — therapeutic diet

English term: therapeutic diet. Arabic operational label: مصطلح therapeutic diet ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"therapeutic diet","term_ar":"مصطلح therapeutic diet ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — allergy

English term: allergy. Arabic operational label: مصطلح allergy ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"allergy","term_ar":"مصطلح allergy ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — owner consent

English term: owner consent. Arabic operational label: مصطلح owner consent ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"owner consent","term_ar":"مصطلح owner consent ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — quarantine

English term: quarantine. Arabic operational label: مصطلح quarantine ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"quarantine","term_ar":"مصطلح quarantine ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — emergency vet

English term: emergency vet. Arabic operational label: مصطلح emergency vet ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"emergency vet","term_ar":"مصطلح emergency vet ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — batch number

English term: batch number. Arabic operational label: مصطلح batch number ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"batch number","term_ar":"مصطلح batch number ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — expiry

English term: expiry. Arabic operational label: مصطلح expiry ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"expiry","term_ar":"مصطلح expiry ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — species

English term: species. Arabic operational label: مصطلح species ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"species","term_ar":"مصطلح species ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — temperament

English term: temperament. Arabic operational label: مصطلح temperament ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"temperament","term_ar":"مصطلح temperament ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن العيادات البيطرية. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن العيادات البيطرية","canonical_subcategory":"veterinary-clinics","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Veterinary clinics. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-veterinary-clinics-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"veterinary-clinics","normalization_only":true}`


# 02. Pet grooming / العناية بالحيوانات الأليفة

**Aliases:** Pet grooming

## industry — Industry scope — Pet grooming

Pet grooming sits within Pet Industry and covers veterinary, grooming, boarding and pet-supply services where species, health, welfare, vaccination, licensed veterinary activity, product suitability and emergency procedures determine safe procurement. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-pet-industry-pet-grooming-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet grooming","aliases_en":["Pet grooming"],"aliases_ar":["العناية بالحيوانات الأليفة"],"sequence":1}`

## industry — UAE procurement workflow — Pet grooming

A typical UAE procurement path for Pet grooming moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-pet-industry-pet-grooming-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet grooming","aliases_en":["Pet grooming"],"aliases_ar":["العناية بالحيوانات الأليفة"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Pet grooming

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include veterinary facility, veterinarian, groomer, boarding operator, authorized importer, distributor. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-pet-industry-pet-grooming-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet grooming","aliases_en":["Pet grooming"],"aliases_ar":["العناية بالحيوانات الأليفة"],"sequence":3}`

## industry — Scope boundaries and escalation — Pet grooming

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Pet grooming. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet grooming","aliases_en":["Pet grooming"],"aliases_ar":["العناية بالحيوانات الأليفة"],"sequence":4}`

## products_services — veterinary consultation

veterinary consultation is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"veterinary consultation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — diagnostic service

diagnostic service is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"diagnostic service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — vaccination

vaccination is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"vaccination","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — surgery/treatment

surgery/treatment is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"surgery/treatment","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet grooming

pet grooming is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet grooming","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — mobile grooming

mobile grooming is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"mobile grooming","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet boarding

pet boarding is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet boarding","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — day care

day care is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"day care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet transport

pet transport is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet transport","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet food

pet food is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet food","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — therapeutic diet

therapeutic diet is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"therapeutic diet","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet accessory

pet accessory is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet accessory","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medication/product

medication/product is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"medication/product","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — animal hygiene product

animal hygiene product is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"animal hygiene product","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — emergency veterinary support

emergency veterinary support is a product or service family relevant to Pet grooming. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-grooming-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"emergency veterinary support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — species/breed/age

Technical topic: species/breed/age. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"species/breed/age","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — animal identity and microchip

Technical topic: animal identity and microchip. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"animal identity and microchip","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — health history

Technical topic: health history. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"health history","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — vaccination status

Technical topic: vaccination status. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"vaccination status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — behaviour/temperament

Technical topic: behaviour/temperament. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"behaviour/temperament","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — licensed veterinary scope

Technical topic: licensed veterinary scope. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"licensed veterinary scope","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — diagnosis/treatment boundary

Technical topic: diagnosis/treatment boundary. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"diagnosis/treatment boundary","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — grooming requirements

Technical topic: grooming requirements. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"grooming requirements","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — boarding capacity and environment

Technical topic: boarding capacity and environment. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"boarding capacity and environment","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — infection control

Technical topic: infection control. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"infection control","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — feeding/diet/allergy

Technical topic: feeding/diet/allergy. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"feeding/diet/allergy","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — medication administration

Technical topic: medication administration. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"medication administration","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — welfare and handling

Technical topic: welfare and handling. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"welfare and handling","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — emergency plan

Technical topic: emergency plan. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"emergency plan","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — owner consent

Technical topic: owner consent. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"owner consent","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — product registration/expiry

Technical topic: product registration/expiry. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"product registration/expiry","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — records and privacy

Technical topic: records and privacy. For Pet grooming, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-grooming-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"records and privacy","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — licensed veterinary clinic

licensed veterinary clinic is a supplier-market role or example for Pet grooming; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-grooming-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed veterinary clinic","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed veterinarian

licensed veterinarian is a supplier-market role or example for Pet grooming; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-grooming-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed veterinarian","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — professional grooming provider

professional grooming provider is a supplier-market role or example for Pet grooming; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-grooming-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"professional grooming provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed boarding facility

licensed boarding facility is a supplier-market role or example for Pet grooming; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-grooming-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed boarding facility","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — authorized pet-food distributor

authorized pet-food distributor is a supplier-market role or example for Pet grooming; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-grooming-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"authorized pet-food distributor","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — pet-product supplier

pet-product supplier is a supplier-market role or example for Pet grooming; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-grooming-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"pet-product supplier","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — veterinary facility

Supplier type: veterinary facility. In Pet grooming, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"veterinary facility","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — veterinary facility

Eligibility gate 1 for a veterinary facility responding to Pet grooming: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"veterinary facility","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — veterinarian

Supplier type: veterinarian. In Pet grooming, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"veterinarian","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — veterinarian

Eligibility gate 2 for a veterinarian responding to Pet grooming: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"veterinarian","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — groomer

Supplier type: groomer. In Pet grooming, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"groomer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — groomer

Eligibility gate 3 for a groomer responding to Pet grooming: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"groomer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — boarding operator

Supplier type: boarding operator. In Pet grooming, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"boarding operator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — boarding operator

Eligibility gate 4 for a boarding operator responding to Pet grooming: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"boarding operator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — authorized importer

Supplier type: authorized importer. In Pet grooming, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"authorized importer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — authorized importer

Eligibility gate 5 for a authorized importer responding to Pet grooming: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"authorized importer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — distributor

Supplier type: distributor. In Pet grooming, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"distributor","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — distributor

Eligibility gate 6 for a distributor responding to Pet grooming: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"distributor","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — pet transport provider

Supplier type: pet transport provider. In Pet grooming, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"pet transport provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — pet transport provider

Eligibility gate 7 for a pet transport provider responding to Pet grooming: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"pet transport provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — emergency clinic

Supplier type: emergency clinic. In Pet grooming, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"emergency clinic","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — emergency clinic

Eligibility gate 8 for a emergency clinic responding to Pet grooming: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"emergency clinic","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — animal/service identity

Quotation requirement: animal/service identity. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"animal_service_identity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — health/vaccination

Quotation requirement: health/vaccination. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"health_vaccination","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — scope and exclusions

Quotation requirement: scope and exclusions. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"scope_and_exclusions","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — facility/licence

Quotation requirement: facility/licence. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"facility_licence","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — diet/medication

Quotation requirement: diet/medication. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"diet_medication","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — welfare/infection control

Quotation requirement: welfare/infection control. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"welfare_infection_control","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — dates/capacity

Quotation requirement: dates/capacity. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"dates_capacity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — emergency/consent

Quotation requirement: emergency/consent. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"emergency_consent","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — product traceability

Quotation requirement: product traceability. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"product_traceability","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — pricing/cancellation

Quotation requirement: pricing/cancellation. Every supplier response for Pet grooming should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-grooming-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"pricing_cancellation","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — animal record

Document: animal record. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"animal_record","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — vaccination certificate

Document: vaccination certificate. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"vaccination_certificate","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — microchip/passport record

Document: microchip/passport record. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"microchip_passport_record","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — medical history

Document: medical history. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"medical_history","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — veterinary prescription

Document: veterinary prescription. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"veterinary_prescription","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — owner consent

Document: owner consent. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"owner_consent","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — boarding/grooming form

Document: boarding/grooming form. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"boarding_grooming_form","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — feeding/medication schedule

Document: feeding/medication schedule. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"feeding_medication_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — facility licence

Document: facility licence. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"facility_licence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — infection-control procedure

Document: infection-control procedure. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"infection_control_procedure","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — emergency contact

Document: emergency contact. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"emergency_contact","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — product label/registration

Document: product label/registration. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"product_label_registration","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — batch/expiry record

Document: batch/expiry record. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"batch_expiry_record","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — service terms

Document: service terms. For Pet grooming, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-grooming-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"service_terms","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Veterinary, Animal Health and Animal Welfare Services

Source activation for Pet grooming: Veterinary, Animal Health and Animal Welfare Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify facility, professional, import, animal welfare and product requirements.

- Record ID: `qd-kb-pet-industry-pet-grooming-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET
- Structured data: `{"source_id":"UAE-MOCCAE-VET","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/services.aspx","source_type":"government_veterinary_portal","live_verification":true}`

## uae_regulations — Agriculture, Food Security, Veterinary and Environmental Services

Source activation for Pet grooming: Agriculture, Food Security, Veterinary and Environmental Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify the current service, permit, registration, environmental and veterinary requirements.

- Record ID: `qd-kb-pet-industry-pet-grooming-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE
- Structured data: `{"source_id":"UAE-MOCCAE","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/home.aspx","source_type":"government_environment_agriculture_portal","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Pet grooming: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-pet-industry-pet-grooming-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Certificate of Conformity for Regulated Products

Source activation for Pet grooming: UAE Certificate of Conformity for Regulated Products (Ministry of Industry and Advanced Technology). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify whether the exact product is regulated and whether the certificate remains valid.

- Record ID: `qd-kb-pet-industry-pet-grooming-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOIAT-CONFORMITY
- Structured data: `{"source_id":"UAE-MOIAT-CONFORMITY","publisher":"Ministry of Industry and Advanced Technology","url":"https://moiat.gov.ae/en/services/issue-conformity-certificates-for-regulated-products","source_type":"government_conformity_service","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Pet grooming: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-pet-industry-pet-grooming-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Pet grooming: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-pet-industry-pet-grooming-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Pet grooming: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-pet-industry-pet-grooming-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Veterinary, Animal Health and Animal Welfare Services

Source activation for Pet grooming: Veterinary, Animal Health and Animal Welfare Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify facility, professional, import, animal welfare and product requirements.

- Record ID: `qd-kb-pet-industry-pet-grooming-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET
- Structured data: `{"source_id":"UAE-MOCCAE-VET","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/services.aspx","source_type":"government_veterinary_portal","live_verification":true}`

## inquiry_qualification — Animal Identity

Ask: What animal species, breed, age, identity and service or product are involved? Arabic: يرجى توضيح animal identity بالنسبة إلى العناية بالحيوانات الأليفة. Reason: animal identity is required to make Pet grooming quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-domain_1","question_en":"What animal species, breed, age, identity and service or product are involved?","question_ar":"يرجى توضيح animal identity بالنسبة إلى العناية بالحيوانات الأليفة.","internal_label_en":"animal identity","internal_label_ar":"متطلب العناية بالحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Health/Vaccination

Ask: What health history, vaccination, allergy, medication, behaviour and special-care needs apply? Arabic: يرجى توضيح health/vaccination بالنسبة إلى العناية بالحيوانات الأليفة. Reason: health/vaccination is required to make Pet grooming quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-domain_2","question_en":"What health history, vaccination, allergy, medication, behaviour and special-care needs apply?","question_ar":"يرجى توضيح health/vaccination بالنسبة إلى العناية بالحيوانات الأليفة.","internal_label_en":"health/vaccination","internal_label_ar":"متطلب العناية بالحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Service Classification

Ask: Is the need veterinary diagnosis/treatment, grooming, boarding, transport, food or supplies? Arabic: يرجى توضيح service classification بالنسبة إلى العناية بالحيوانات الأليفة. Reason: service classification is required to make Pet grooming quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-domain_3","question_en":"Is the need veterinary diagnosis/treatment, grooming, boarding, transport, food or supplies?","question_ar":"يرجى توضيح service classification بالنسبة إلى العناية بالحيوانات الأليفة.","internal_label_en":"service classification","internal_label_ar":"متطلب العناية بالحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Licence/Consent

Ask: Which licensed veterinary/facility scope and owner consent are required? Arabic: يرجى توضيح licence/consent بالنسبة إلى العناية بالحيوانات الأليفة. Reason: licence/consent is required to make Pet grooming quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-domain_4","question_en":"Which licensed veterinary/facility scope and owner consent are required?","question_ar":"يرجى توضيح licence/consent بالنسبة إلى العناية بالحيوانات الأليفة.","internal_label_en":"licence/consent","internal_label_ar":"متطلب العناية بالحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Welfare/Care

Ask: What welfare, handling, infection-control, diet and medication procedures apply? Arabic: يرجى توضيح welfare/care بالنسبة إلى العناية بالحيوانات الأليفة. Reason: welfare/care is required to make Pet grooming quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-domain_5","question_en":"What welfare, handling, infection-control, diet and medication procedures apply?","question_ar":"يرجى توضيح welfare/care بالنسبة إلى العناية بالحيوانات الأليفة.","internal_label_en":"welfare/care","internal_label_ar":"متطلب العناية بالحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Schedule/Emergency

Ask: What dates, boarding/grooming capacity, emergency and contingency arrangements are required? Arabic: يرجى توضيح schedule/emergency بالنسبة إلى العناية بالحيوانات الأليفة. Reason: schedule/emergency is required to make Pet grooming quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-domain_6","question_en":"What dates, boarding/grooming capacity, emergency and contingency arrangements are required?","question_ar":"يرجى توضيح schedule/emergency بالنسبة إلى العناية بالحيوانات الأليفة.","internal_label_en":"schedule/emergency","internal_label_ar":"متطلب العناية بالحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Product/Commercial

Ask: What product registration, batch, expiry, pricing, cancellation and complaint terms apply? Arabic: يرجى توضيح product/commercial بالنسبة إلى العناية بالحيوانات الأليفة. Reason: product/commercial is required to make Pet grooming quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-domain_7","question_en":"What product registration, batch, expiry, pricing, cancellation and complaint terms apply?","question_ar":"يرجى توضيح product/commercial بالنسبة إلى العناية بالحيوانات الأليفة.","internal_label_en":"product/commercial","internal_label_ar":"متطلب العناية بالحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Pet grooming quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Pet grooming quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Pet grooming quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Pet grooming quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Pet grooming quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Pet grooming quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Pet grooming quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Pet grooming quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Pet grooming quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Pet grooming quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Pet grooming quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Pet grooming quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Pet grooming quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Pet grooming quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Pet grooming quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Pet grooming quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Pet grooming quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Pet grooming quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Pet grooming quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Pet grooming quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Pet grooming quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Pet grooming quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-grooming-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Pet grooming, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-grooming-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-grooming-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Pet grooming; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-grooming-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Pet grooming; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-grooming-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Pet grooming; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-grooming-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Pet grooming; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-grooming-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Pet grooming; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-grooming-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-grooming-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Pet grooming: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-grooming-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Pet grooming: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-grooming-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Pet grooming: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-grooming-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Pet grooming: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-pet-grooming-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Pet grooming: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-grooming-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Pet grooming: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-grooming-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Pet grooming: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-pet-grooming-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Pet grooming: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-grooming-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Pet grooming: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-grooming-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Pet grooming: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-grooming-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-pet-grooming-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — clinical complexity

Cost driver: clinical complexity. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"clinical complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — animal size/behaviour

Cost driver: animal size/behaviour. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"animal size/behaviour","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — boarding duration

Cost driver: boarding duration. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"boarding duration","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — special diet/medication

Cost driver: special diet/medication. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"special diet/medication","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — emergency coverage

Cost driver: emergency coverage. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"emergency coverage","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — product type and import status

Cost driver: product type and import status. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"product type and import status","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Pet grooming quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-grooming-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Pet grooming: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Pet grooming: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Pet grooming: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Pet grooming: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Pet grooming: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Pet grooming: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Pet grooming: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Pet grooming: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Pet grooming: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Pet grooming: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-grooming-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — unlicensed veterinary treatment

Risk: unlicensed veterinary treatment. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"unlicensed veterinary treatment","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — missing vaccination

Risk: missing vaccination. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"missing vaccination","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — animal escape/injury

Risk: animal escape/injury. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"animal escape/injury","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — infection outbreak

Risk: infection outbreak. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"infection outbreak","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — wrong food/medication

Risk: wrong food/medication. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"wrong food/medication","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — poor emergency response

Risk: poor emergency response. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"poor emergency response","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Pet grooming, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-grooming-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Pet grooming: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-grooming-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Pet grooming: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-grooming-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Pet grooming: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-grooming-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Pet grooming: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-grooming-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Pet grooming: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-grooming-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Pet grooming: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-grooming-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Pet grooming, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-grooming-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Pet grooming, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-grooming-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Pet grooming, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-grooming-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Pet grooming, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-grooming-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Pet grooming, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-grooming-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Pet grooming, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-grooming-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Pet grooming, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-grooming-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Pet grooming, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-grooming-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Pet grooming: vague public request. Input: I need help with Pet grooming but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-grooming-01","input":{"message":"I need help with Pet grooming but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Pet grooming: minimum quote-ready request. Input: Customer requests Pet grooming and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-grooming-02","input":{"message":"Customer requests Pet grooming and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Pet grooming: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-grooming-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Pet grooming: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-grooming-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Pet grooming: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-grooming-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Pet grooming: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-grooming-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Pet grooming: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-grooming-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-grooming-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — microchip

English term: microchip. Arabic operational label: مصطلح microchip ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"microchip","term_ar":"مصطلح microchip ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — vaccination certificate

English term: vaccination certificate. Arabic operational label: مصطلح vaccination certificate ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"vaccination certificate","term_ar":"مصطلح vaccination certificate ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — veterinary prescription

English term: veterinary prescription. Arabic operational label: مصطلح veterinary prescription ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"veterinary prescription","term_ar":"مصطلح veterinary prescription ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — animal welfare

English term: animal welfare. Arabic operational label: مصطلح animal welfare ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"animal welfare","term_ar":"مصطلح animal welfare ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — boarding

English term: boarding. Arabic operational label: مصطلح boarding ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"boarding","term_ar":"مصطلح boarding ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — grooming

English term: grooming. Arabic operational label: مصطلح grooming ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"grooming","term_ar":"مصطلح grooming ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — infection control

English term: infection control. Arabic operational label: مصطلح infection control ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"infection control","term_ar":"مصطلح infection control ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — therapeutic diet

English term: therapeutic diet. Arabic operational label: مصطلح therapeutic diet ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"therapeutic diet","term_ar":"مصطلح therapeutic diet ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — allergy

English term: allergy. Arabic operational label: مصطلح allergy ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"allergy","term_ar":"مصطلح allergy ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — owner consent

English term: owner consent. Arabic operational label: مصطلح owner consent ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"owner consent","term_ar":"مصطلح owner consent ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — quarantine

English term: quarantine. Arabic operational label: مصطلح quarantine ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"quarantine","term_ar":"مصطلح quarantine ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — emergency vet

English term: emergency vet. Arabic operational label: مصطلح emergency vet ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"emergency vet","term_ar":"مصطلح emergency vet ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — batch number

English term: batch number. Arabic operational label: مصطلح batch number ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"batch number","term_ar":"مصطلح batch number ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — expiry

English term: expiry. Arabic operational label: مصطلح expiry ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"expiry","term_ar":"مصطلح expiry ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — species

English term: species. Arabic operational label: مصطلح species ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"species","term_ar":"مصطلح species ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — temperament

English term: temperament. Arabic operational label: مصطلح temperament ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"temperament","term_ar":"مصطلح temperament ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن العناية بالحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن العناية بالحيوانات الأليفة","canonical_subcategory":"pet-grooming","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Pet grooming. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-grooming-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"pet-grooming","normalization_only":true}`


# 03. Pet boarding / إيواء الحيوانات الأليفة

**Aliases:** Pet boarding

## industry — Industry scope — Pet boarding

Pet boarding sits within Pet Industry and covers veterinary, grooming, boarding and pet-supply services where species, health, welfare, vaccination, licensed veterinary activity, product suitability and emergency procedures determine safe procurement. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-pet-industry-pet-boarding-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet boarding","aliases_en":["Pet boarding"],"aliases_ar":["إيواء الحيوانات الأليفة"],"sequence":1}`

## industry — UAE procurement workflow — Pet boarding

A typical UAE procurement path for Pet boarding moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-pet-industry-pet-boarding-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet boarding","aliases_en":["Pet boarding"],"aliases_ar":["إيواء الحيوانات الأليفة"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Pet boarding

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include veterinary facility, veterinarian, groomer, boarding operator, authorized importer, distributor. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-pet-industry-pet-boarding-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet boarding","aliases_en":["Pet boarding"],"aliases_ar":["إيواء الحيوانات الأليفة"],"sequence":3}`

## industry — Scope boundaries and escalation — Pet boarding

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Pet boarding. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet boarding","aliases_en":["Pet boarding"],"aliases_ar":["إيواء الحيوانات الأليفة"],"sequence":4}`

## products_services — veterinary consultation

veterinary consultation is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"veterinary consultation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — diagnostic service

diagnostic service is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"diagnostic service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — vaccination

vaccination is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"vaccination","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — surgery/treatment

surgery/treatment is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"surgery/treatment","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet grooming

pet grooming is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet grooming","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — mobile grooming

mobile grooming is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"mobile grooming","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet boarding

pet boarding is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet boarding","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — day care

day care is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"day care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet transport

pet transport is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet transport","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet food

pet food is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet food","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — therapeutic diet

therapeutic diet is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"therapeutic diet","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet accessory

pet accessory is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet accessory","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medication/product

medication/product is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"medication/product","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — animal hygiene product

animal hygiene product is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"animal hygiene product","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — emergency veterinary support

emergency veterinary support is a product or service family relevant to Pet boarding. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-boarding-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"emergency veterinary support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — species/breed/age

Technical topic: species/breed/age. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"species/breed/age","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — animal identity and microchip

Technical topic: animal identity and microchip. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"animal identity and microchip","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — health history

Technical topic: health history. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"health history","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — vaccination status

Technical topic: vaccination status. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"vaccination status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — behaviour/temperament

Technical topic: behaviour/temperament. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"behaviour/temperament","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — licensed veterinary scope

Technical topic: licensed veterinary scope. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"licensed veterinary scope","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — diagnosis/treatment boundary

Technical topic: diagnosis/treatment boundary. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"diagnosis/treatment boundary","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — grooming requirements

Technical topic: grooming requirements. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"grooming requirements","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — boarding capacity and environment

Technical topic: boarding capacity and environment. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"boarding capacity and environment","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — infection control

Technical topic: infection control. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"infection control","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — feeding/diet/allergy

Technical topic: feeding/diet/allergy. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"feeding/diet/allergy","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — medication administration

Technical topic: medication administration. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"medication administration","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — welfare and handling

Technical topic: welfare and handling. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"welfare and handling","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — emergency plan

Technical topic: emergency plan. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"emergency plan","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — owner consent

Technical topic: owner consent. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"owner consent","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — product registration/expiry

Technical topic: product registration/expiry. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"product registration/expiry","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — records and privacy

Technical topic: records and privacy. For Pet boarding, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-boarding-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"records and privacy","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — licensed veterinary clinic

licensed veterinary clinic is a supplier-market role or example for Pet boarding; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-boarding-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed veterinary clinic","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed veterinarian

licensed veterinarian is a supplier-market role or example for Pet boarding; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-boarding-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed veterinarian","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — professional grooming provider

professional grooming provider is a supplier-market role or example for Pet boarding; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-boarding-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"professional grooming provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed boarding facility

licensed boarding facility is a supplier-market role or example for Pet boarding; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-boarding-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed boarding facility","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — authorized pet-food distributor

authorized pet-food distributor is a supplier-market role or example for Pet boarding; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-boarding-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"authorized pet-food distributor","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — pet-product supplier

pet-product supplier is a supplier-market role or example for Pet boarding; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-boarding-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"pet-product supplier","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — veterinary facility

Supplier type: veterinary facility. In Pet boarding, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"veterinary facility","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — veterinary facility

Eligibility gate 1 for a veterinary facility responding to Pet boarding: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"veterinary facility","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — veterinarian

Supplier type: veterinarian. In Pet boarding, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"veterinarian","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — veterinarian

Eligibility gate 2 for a veterinarian responding to Pet boarding: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"veterinarian","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — groomer

Supplier type: groomer. In Pet boarding, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"groomer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — groomer

Eligibility gate 3 for a groomer responding to Pet boarding: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"groomer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — boarding operator

Supplier type: boarding operator. In Pet boarding, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"boarding operator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — boarding operator

Eligibility gate 4 for a boarding operator responding to Pet boarding: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"boarding operator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — authorized importer

Supplier type: authorized importer. In Pet boarding, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"authorized importer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — authorized importer

Eligibility gate 5 for a authorized importer responding to Pet boarding: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"authorized importer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — distributor

Supplier type: distributor. In Pet boarding, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"distributor","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — distributor

Eligibility gate 6 for a distributor responding to Pet boarding: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"distributor","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — pet transport provider

Supplier type: pet transport provider. In Pet boarding, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"pet transport provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — pet transport provider

Eligibility gate 7 for a pet transport provider responding to Pet boarding: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"pet transport provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — emergency clinic

Supplier type: emergency clinic. In Pet boarding, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"emergency clinic","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — emergency clinic

Eligibility gate 8 for a emergency clinic responding to Pet boarding: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"emergency clinic","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — animal/service identity

Quotation requirement: animal/service identity. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"animal_service_identity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — health/vaccination

Quotation requirement: health/vaccination. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"health_vaccination","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — scope and exclusions

Quotation requirement: scope and exclusions. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"scope_and_exclusions","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — facility/licence

Quotation requirement: facility/licence. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"facility_licence","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — diet/medication

Quotation requirement: diet/medication. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"diet_medication","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — welfare/infection control

Quotation requirement: welfare/infection control. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"welfare_infection_control","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — dates/capacity

Quotation requirement: dates/capacity. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"dates_capacity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — emergency/consent

Quotation requirement: emergency/consent. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"emergency_consent","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — product traceability

Quotation requirement: product traceability. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"product_traceability","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — pricing/cancellation

Quotation requirement: pricing/cancellation. Every supplier response for Pet boarding should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-boarding-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"pricing_cancellation","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — animal record

Document: animal record. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"animal_record","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — vaccination certificate

Document: vaccination certificate. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"vaccination_certificate","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — microchip/passport record

Document: microchip/passport record. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"microchip_passport_record","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — medical history

Document: medical history. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"medical_history","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — veterinary prescription

Document: veterinary prescription. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"veterinary_prescription","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — owner consent

Document: owner consent. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"owner_consent","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — boarding/grooming form

Document: boarding/grooming form. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"boarding_grooming_form","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — feeding/medication schedule

Document: feeding/medication schedule. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"feeding_medication_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — facility licence

Document: facility licence. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"facility_licence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — infection-control procedure

Document: infection-control procedure. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"infection_control_procedure","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — emergency contact

Document: emergency contact. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"emergency_contact","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — product label/registration

Document: product label/registration. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"product_label_registration","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — batch/expiry record

Document: batch/expiry record. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"batch_expiry_record","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — service terms

Document: service terms. For Pet boarding, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-boarding-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"service_terms","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Veterinary, Animal Health and Animal Welfare Services

Source activation for Pet boarding: Veterinary, Animal Health and Animal Welfare Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify facility, professional, import, animal welfare and product requirements.

- Record ID: `qd-kb-pet-industry-pet-boarding-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET
- Structured data: `{"source_id":"UAE-MOCCAE-VET","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/services.aspx","source_type":"government_veterinary_portal","live_verification":true}`

## uae_regulations — Agriculture, Food Security, Veterinary and Environmental Services

Source activation for Pet boarding: Agriculture, Food Security, Veterinary and Environmental Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify the current service, permit, registration, environmental and veterinary requirements.

- Record ID: `qd-kb-pet-industry-pet-boarding-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE
- Structured data: `{"source_id":"UAE-MOCCAE","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/home.aspx","source_type":"government_environment_agriculture_portal","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Pet boarding: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-pet-industry-pet-boarding-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Certificate of Conformity for Regulated Products

Source activation for Pet boarding: UAE Certificate of Conformity for Regulated Products (Ministry of Industry and Advanced Technology). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify whether the exact product is regulated and whether the certificate remains valid.

- Record ID: `qd-kb-pet-industry-pet-boarding-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOIAT-CONFORMITY
- Structured data: `{"source_id":"UAE-MOIAT-CONFORMITY","publisher":"Ministry of Industry and Advanced Technology","url":"https://moiat.gov.ae/en/services/issue-conformity-certificates-for-regulated-products","source_type":"government_conformity_service","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Pet boarding: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-pet-industry-pet-boarding-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Pet boarding: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-pet-industry-pet-boarding-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Pet boarding: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-pet-industry-pet-boarding-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Veterinary, Animal Health and Animal Welfare Services

Source activation for Pet boarding: Veterinary, Animal Health and Animal Welfare Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify facility, professional, import, animal welfare and product requirements.

- Record ID: `qd-kb-pet-industry-pet-boarding-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET
- Structured data: `{"source_id":"UAE-MOCCAE-VET","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/services.aspx","source_type":"government_veterinary_portal","live_verification":true}`

## inquiry_qualification — Animal Identity

Ask: What animal species, breed, age, identity and service or product are involved? Arabic: يرجى توضيح animal identity بالنسبة إلى إيواء الحيوانات الأليفة. Reason: animal identity is required to make Pet boarding quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-domain_1","question_en":"What animal species, breed, age, identity and service or product are involved?","question_ar":"يرجى توضيح animal identity بالنسبة إلى إيواء الحيوانات الأليفة.","internal_label_en":"animal identity","internal_label_ar":"متطلب إيواء الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Health/Vaccination

Ask: What health history, vaccination, allergy, medication, behaviour and special-care needs apply? Arabic: يرجى توضيح health/vaccination بالنسبة إلى إيواء الحيوانات الأليفة. Reason: health/vaccination is required to make Pet boarding quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-domain_2","question_en":"What health history, vaccination, allergy, medication, behaviour and special-care needs apply?","question_ar":"يرجى توضيح health/vaccination بالنسبة إلى إيواء الحيوانات الأليفة.","internal_label_en":"health/vaccination","internal_label_ar":"متطلب إيواء الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Service Classification

Ask: Is the need veterinary diagnosis/treatment, grooming, boarding, transport, food or supplies? Arabic: يرجى توضيح service classification بالنسبة إلى إيواء الحيوانات الأليفة. Reason: service classification is required to make Pet boarding quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-domain_3","question_en":"Is the need veterinary diagnosis/treatment, grooming, boarding, transport, food or supplies?","question_ar":"يرجى توضيح service classification بالنسبة إلى إيواء الحيوانات الأليفة.","internal_label_en":"service classification","internal_label_ar":"متطلب إيواء الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Licence/Consent

Ask: Which licensed veterinary/facility scope and owner consent are required? Arabic: يرجى توضيح licence/consent بالنسبة إلى إيواء الحيوانات الأليفة. Reason: licence/consent is required to make Pet boarding quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-domain_4","question_en":"Which licensed veterinary/facility scope and owner consent are required?","question_ar":"يرجى توضيح licence/consent بالنسبة إلى إيواء الحيوانات الأليفة.","internal_label_en":"licence/consent","internal_label_ar":"متطلب إيواء الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Welfare/Care

Ask: What welfare, handling, infection-control, diet and medication procedures apply? Arabic: يرجى توضيح welfare/care بالنسبة إلى إيواء الحيوانات الأليفة. Reason: welfare/care is required to make Pet boarding quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-domain_5","question_en":"What welfare, handling, infection-control, diet and medication procedures apply?","question_ar":"يرجى توضيح welfare/care بالنسبة إلى إيواء الحيوانات الأليفة.","internal_label_en":"welfare/care","internal_label_ar":"متطلب إيواء الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Schedule/Emergency

Ask: What dates, boarding/grooming capacity, emergency and contingency arrangements are required? Arabic: يرجى توضيح schedule/emergency بالنسبة إلى إيواء الحيوانات الأليفة. Reason: schedule/emergency is required to make Pet boarding quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-domain_6","question_en":"What dates, boarding/grooming capacity, emergency and contingency arrangements are required?","question_ar":"يرجى توضيح schedule/emergency بالنسبة إلى إيواء الحيوانات الأليفة.","internal_label_en":"schedule/emergency","internal_label_ar":"متطلب إيواء الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Product/Commercial

Ask: What product registration, batch, expiry, pricing, cancellation and complaint terms apply? Arabic: يرجى توضيح product/commercial بالنسبة إلى إيواء الحيوانات الأليفة. Reason: product/commercial is required to make Pet boarding quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-domain_7","question_en":"What product registration, batch, expiry, pricing, cancellation and complaint terms apply?","question_ar":"يرجى توضيح product/commercial بالنسبة إلى إيواء الحيوانات الأليفة.","internal_label_en":"product/commercial","internal_label_ar":"متطلب إيواء الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Pet boarding quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Pet boarding quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Pet boarding quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Pet boarding quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Pet boarding quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Pet boarding quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Pet boarding quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Pet boarding quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Pet boarding quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Pet boarding quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Pet boarding quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Pet boarding quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Pet boarding quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Pet boarding quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Pet boarding quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Pet boarding quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Pet boarding quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Pet boarding quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Pet boarding quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Pet boarding quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Pet boarding quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Pet boarding quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-boarding-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Pet boarding, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-boarding-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-boarding-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Pet boarding; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-boarding-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Pet boarding; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-boarding-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Pet boarding; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-boarding-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Pet boarding; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-boarding-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Pet boarding; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-boarding-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-boarding-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Pet boarding: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-boarding-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Pet boarding: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-boarding-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Pet boarding: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-boarding-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Pet boarding: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-pet-boarding-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Pet boarding: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-boarding-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Pet boarding: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-boarding-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Pet boarding: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-pet-boarding-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Pet boarding: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-boarding-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Pet boarding: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-boarding-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Pet boarding: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-boarding-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-pet-boarding-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — clinical complexity

Cost driver: clinical complexity. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"clinical complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — animal size/behaviour

Cost driver: animal size/behaviour. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"animal size/behaviour","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — boarding duration

Cost driver: boarding duration. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"boarding duration","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — special diet/medication

Cost driver: special diet/medication. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"special diet/medication","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — emergency coverage

Cost driver: emergency coverage. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"emergency coverage","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — product type and import status

Cost driver: product type and import status. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"product type and import status","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Pet boarding quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-boarding-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Pet boarding: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Pet boarding: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Pet boarding: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Pet boarding: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Pet boarding: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Pet boarding: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Pet boarding: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Pet boarding: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Pet boarding: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Pet boarding: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-boarding-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — unlicensed veterinary treatment

Risk: unlicensed veterinary treatment. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"unlicensed veterinary treatment","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — missing vaccination

Risk: missing vaccination. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"missing vaccination","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — animal escape/injury

Risk: animal escape/injury. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"animal escape/injury","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — infection outbreak

Risk: infection outbreak. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"infection outbreak","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — wrong food/medication

Risk: wrong food/medication. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"wrong food/medication","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — poor emergency response

Risk: poor emergency response. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"poor emergency response","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Pet boarding, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-boarding-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Pet boarding: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-boarding-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Pet boarding: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-boarding-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Pet boarding: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-boarding-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Pet boarding: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-boarding-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Pet boarding: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-boarding-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Pet boarding: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-boarding-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Pet boarding, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-boarding-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Pet boarding, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-boarding-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Pet boarding, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-boarding-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Pet boarding, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-boarding-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Pet boarding, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-boarding-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Pet boarding, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-boarding-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Pet boarding, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-boarding-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Pet boarding, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-boarding-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Pet boarding: vague public request. Input: I need help with Pet boarding but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-boarding-01","input":{"message":"I need help with Pet boarding but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Pet boarding: minimum quote-ready request. Input: Customer requests Pet boarding and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-boarding-02","input":{"message":"Customer requests Pet boarding and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Pet boarding: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-boarding-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Pet boarding: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-boarding-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Pet boarding: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-boarding-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Pet boarding: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-boarding-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Pet boarding: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-boarding-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-boarding-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — microchip

English term: microchip. Arabic operational label: مصطلح microchip ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"microchip","term_ar":"مصطلح microchip ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — vaccination certificate

English term: vaccination certificate. Arabic operational label: مصطلح vaccination certificate ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"vaccination certificate","term_ar":"مصطلح vaccination certificate ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — veterinary prescription

English term: veterinary prescription. Arabic operational label: مصطلح veterinary prescription ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"veterinary prescription","term_ar":"مصطلح veterinary prescription ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — animal welfare

English term: animal welfare. Arabic operational label: مصطلح animal welfare ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"animal welfare","term_ar":"مصطلح animal welfare ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — boarding

English term: boarding. Arabic operational label: مصطلح boarding ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"boarding","term_ar":"مصطلح boarding ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — grooming

English term: grooming. Arabic operational label: مصطلح grooming ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"grooming","term_ar":"مصطلح grooming ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — infection control

English term: infection control. Arabic operational label: مصطلح infection control ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"infection control","term_ar":"مصطلح infection control ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — therapeutic diet

English term: therapeutic diet. Arabic operational label: مصطلح therapeutic diet ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"therapeutic diet","term_ar":"مصطلح therapeutic diet ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — allergy

English term: allergy. Arabic operational label: مصطلح allergy ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"allergy","term_ar":"مصطلح allergy ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — owner consent

English term: owner consent. Arabic operational label: مصطلح owner consent ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"owner consent","term_ar":"مصطلح owner consent ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — quarantine

English term: quarantine. Arabic operational label: مصطلح quarantine ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"quarantine","term_ar":"مصطلح quarantine ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — emergency vet

English term: emergency vet. Arabic operational label: مصطلح emergency vet ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"emergency vet","term_ar":"مصطلح emergency vet ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — batch number

English term: batch number. Arabic operational label: مصطلح batch number ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"batch number","term_ar":"مصطلح batch number ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — expiry

English term: expiry. Arabic operational label: مصطلح expiry ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"expiry","term_ar":"مصطلح expiry ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — species

English term: species. Arabic operational label: مصطلح species ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"species","term_ar":"مصطلح species ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — temperament

English term: temperament. Arabic operational label: مصطلح temperament ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"temperament","term_ar":"مصطلح temperament ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن إيواء الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن إيواء الحيوانات الأليفة","canonical_subcategory":"pet-boarding","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Pet boarding. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-boarding-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"pet-boarding","normalization_only":true}`


# 04. Pet food & supplies / أغذية ومستلزمات الحيوانات الأليفة

**Aliases:** Pet food & supplies, Pet food, supplies

## industry — Industry scope — Pet food & supplies

Pet food & supplies sits within Pet Industry and covers veterinary, grooming, boarding and pet-supply services where species, health, welfare, vaccination, licensed veterinary activity, product suitability and emergency procedures determine safe procurement. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet food & supplies","aliases_en":["Pet food & supplies","Pet food","supplies"],"aliases_ar":["أغذية ومستلزمات الحيوانات الأليفة"],"sequence":1}`

## industry — UAE procurement workflow — Pet food & supplies

A typical UAE procurement path for Pet food & supplies moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet food & supplies","aliases_en":["Pet food & supplies","Pet food","supplies"],"aliases_ar":["أغذية ومستلزمات الحيوانات الأليفة"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Pet food & supplies

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include veterinary facility, veterinarian, groomer, boarding operator, authorized importer, distributor. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet food & supplies","aliases_en":["Pet food & supplies","Pet food","supplies"],"aliases_ar":["أغذية ومستلزمات الحيوانات الأليفة"],"sequence":3}`

## industry — Scope boundaries and escalation — Pet food & supplies

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Pet food & supplies. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"subcategory":"Pet food & supplies","aliases_en":["Pet food & supplies","Pet food","supplies"],"aliases_ar":["أغذية ومستلزمات الحيوانات الأليفة"],"sequence":4}`

## products_services — veterinary consultation

veterinary consultation is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"veterinary consultation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — diagnostic service

diagnostic service is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"diagnostic service","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — vaccination

vaccination is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"vaccination","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — surgery/treatment

surgery/treatment is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"surgery/treatment","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet grooming

pet grooming is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet grooming","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — mobile grooming

mobile grooming is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"mobile grooming","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet boarding

pet boarding is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet boarding","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — day care

day care is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"day care","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet transport

pet transport is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet transport","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet food

pet food is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet food","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — therapeutic diet

therapeutic diet is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"therapeutic diet","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — pet accessory

pet accessory is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"pet accessory","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medication/product

medication/product is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"medication/product","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — animal hygiene product

animal hygiene product is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"animal hygiene product","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — emergency veterinary support

emergency veterinary support is a product or service family relevant to Pet food & supplies. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"family":"emergency veterinary support","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — species/breed/age

Technical topic: species/breed/age. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"species/breed/age","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — animal identity and microchip

Technical topic: animal identity and microchip. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"animal identity and microchip","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — health history

Technical topic: health history. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"health history","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — vaccination status

Technical topic: vaccination status. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"vaccination status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — behaviour/temperament

Technical topic: behaviour/temperament. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"behaviour/temperament","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — licensed veterinary scope

Technical topic: licensed veterinary scope. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"licensed veterinary scope","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — diagnosis/treatment boundary

Technical topic: diagnosis/treatment boundary. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"diagnosis/treatment boundary","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — grooming requirements

Technical topic: grooming requirements. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"grooming requirements","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — boarding capacity and environment

Technical topic: boarding capacity and environment. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"boarding capacity and environment","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — infection control

Technical topic: infection control. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"infection control","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — feeding/diet/allergy

Technical topic: feeding/diet/allergy. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"feeding/diet/allergy","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — medication administration

Technical topic: medication administration. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"medication administration","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — welfare and handling

Technical topic: welfare and handling. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"welfare and handling","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — emergency plan

Technical topic: emergency plan. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"emergency plan","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — owner consent

Technical topic: owner consent. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"owner consent","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — product registration/expiry

Technical topic: product registration/expiry. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"product registration/expiry","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — records and privacy

Technical topic: records and privacy. For Pet food & supplies, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"topic":"records and privacy","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — licensed veterinary clinic

licensed veterinary clinic is a supplier-market role or example for Pet food & supplies; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed veterinary clinic","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed veterinarian

licensed veterinarian is a supplier-market role or example for Pet food & supplies; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed veterinarian","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — professional grooming provider

professional grooming provider is a supplier-market role or example for Pet food & supplies; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"professional grooming provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — licensed boarding facility

licensed boarding facility is a supplier-market role or example for Pet food & supplies; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"licensed boarding facility","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — authorized pet-food distributor

authorized pet-food distributor is a supplier-market role or example for Pet food & supplies; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"authorized pet-food distributor","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — pet-product supplier

pet-product supplier is a supplier-market role or example for Pet food & supplies; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"pet-product supplier","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — veterinary facility

Supplier type: veterinary facility. In Pet food & supplies, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"veterinary facility","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — veterinary facility

Eligibility gate 1 for a veterinary facility responding to Pet food & supplies: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"veterinary facility","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — veterinarian

Supplier type: veterinarian. In Pet food & supplies, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"veterinarian","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — veterinarian

Eligibility gate 2 for a veterinarian responding to Pet food & supplies: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"veterinarian","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — groomer

Supplier type: groomer. In Pet food & supplies, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"groomer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — groomer

Eligibility gate 3 for a groomer responding to Pet food & supplies: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"groomer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — boarding operator

Supplier type: boarding operator. In Pet food & supplies, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"boarding operator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — boarding operator

Eligibility gate 4 for a boarding operator responding to Pet food & supplies: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"boarding operator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — authorized importer

Supplier type: authorized importer. In Pet food & supplies, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"authorized importer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — authorized importer

Eligibility gate 5 for a authorized importer responding to Pet food & supplies: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"authorized importer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — distributor

Supplier type: distributor. In Pet food & supplies, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"distributor","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — distributor

Eligibility gate 6 for a distributor responding to Pet food & supplies: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"distributor","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — pet transport provider

Supplier type: pet transport provider. In Pet food & supplies, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"pet transport provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — pet transport provider

Eligibility gate 7 for a pet transport provider responding to Pet food & supplies: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"pet transport provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — emergency clinic

Supplier type: emergency clinic. In Pet food & supplies, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"supplier_type":"emergency clinic","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — emergency clinic

Eligibility gate 8 for a emergency clinic responding to Pet food & supplies: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"supplier_type":"emergency clinic","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — animal/service identity

Quotation requirement: animal/service identity. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"animal_service_identity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — health/vaccination

Quotation requirement: health/vaccination. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"health_vaccination","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — scope and exclusions

Quotation requirement: scope and exclusions. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"scope_and_exclusions","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — facility/licence

Quotation requirement: facility/licence. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"facility_licence","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — diet/medication

Quotation requirement: diet/medication. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"diet_medication","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — welfare/infection control

Quotation requirement: welfare/infection control. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"welfare_infection_control","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — dates/capacity

Quotation requirement: dates/capacity. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"dates_capacity","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — emergency/consent

Quotation requirement: emergency/consent. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"emergency_consent","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — product traceability

Quotation requirement: product traceability. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"product_traceability","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — pricing/cancellation

Quotation requirement: pricing/cancellation. Every supplier response for Pet food & supplies should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"quotation_field":"pricing_cancellation","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — animal record

Document: animal record. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"animal_record","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — vaccination certificate

Document: vaccination certificate. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"vaccination_certificate","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — microchip/passport record

Document: microchip/passport record. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"microchip_passport_record","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — medical history

Document: medical history. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"medical_history","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — veterinary prescription

Document: veterinary prescription. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"veterinary_prescription","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — owner consent

Document: owner consent. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"owner_consent","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — boarding/grooming form

Document: boarding/grooming form. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"boarding_grooming_form","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — feeding/medication schedule

Document: feeding/medication schedule. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"feeding_medication_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — facility licence

Document: facility licence. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"facility_licence","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — infection-control procedure

Document: infection-control procedure. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"infection_control_procedure","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — emergency contact

Document: emergency contact. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"emergency_contact","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — product label/registration

Document: product label/registration. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"product_label_registration","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — batch/expiry record

Document: batch/expiry record. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"batch_expiry_record","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — service terms

Document: service terms. For Pet food & supplies, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"document_type":"service_terms","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Veterinary, Animal Health and Animal Welfare Services

Source activation for Pet food & supplies: Veterinary, Animal Health and Animal Welfare Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify facility, professional, import, animal welfare and product requirements.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET
- Structured data: `{"source_id":"UAE-MOCCAE-VET","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/services.aspx","source_type":"government_veterinary_portal","live_verification":true}`

## uae_regulations — Agriculture, Food Security, Veterinary and Environmental Services

Source activation for Pet food & supplies: Agriculture, Food Security, Veterinary and Environmental Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify the current service, permit, registration, environmental and veterinary requirements.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE
- Structured data: `{"source_id":"UAE-MOCCAE","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/home.aspx","source_type":"government_environment_agriculture_portal","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Pet food & supplies: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — UAE Certificate of Conformity for Regulated Products

Source activation for Pet food & supplies: UAE Certificate of Conformity for Regulated Products (Ministry of Industry and Advanced Technology). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify whether the exact product is regulated and whether the certificate remains valid.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOIAT-CONFORMITY
- Structured data: `{"source_id":"UAE-MOIAT-CONFORMITY","publisher":"Ministry of Industry and Advanced Technology","url":"https://moiat.gov.ae/en/services/issue-conformity-certificates-for-regulated-products","source_type":"government_conformity_service","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Pet food & supplies: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Pet food & supplies: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Pet food & supplies: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Veterinary, Animal Health and Animal Welfare Services

Source activation for Pet food & supplies: Veterinary, Animal Health and Animal Welfare Services (Ministry of Climate Change and Environment). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify facility, professional, import, animal welfare and product requirements.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET
- Structured data: `{"source_id":"UAE-MOCCAE-VET","publisher":"Ministry of Climate Change and Environment","url":"https://www.moccae.gov.ae/en/services.aspx","source_type":"government_veterinary_portal","live_verification":true}`

## inquiry_qualification — Animal Identity

Ask: What animal species, breed, age, identity and service or product are involved? Arabic: يرجى توضيح animal identity بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة. Reason: animal identity is required to make Pet food & supplies quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-domain_1","question_en":"What animal species, breed, age, identity and service or product are involved?","question_ar":"يرجى توضيح animal identity بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة.","internal_label_en":"animal identity","internal_label_ar":"متطلب أغذية ومستلزمات الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Health/Vaccination

Ask: What health history, vaccination, allergy, medication, behaviour and special-care needs apply? Arabic: يرجى توضيح health/vaccination بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة. Reason: health/vaccination is required to make Pet food & supplies quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-domain_2","question_en":"What health history, vaccination, allergy, medication, behaviour and special-care needs apply?","question_ar":"يرجى توضيح health/vaccination بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة.","internal_label_en":"health/vaccination","internal_label_ar":"متطلب أغذية ومستلزمات الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Service Classification

Ask: Is the need veterinary diagnosis/treatment, grooming, boarding, transport, food or supplies? Arabic: يرجى توضيح service classification بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة. Reason: service classification is required to make Pet food & supplies quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-domain_3","question_en":"Is the need veterinary diagnosis/treatment, grooming, boarding, transport, food or supplies?","question_ar":"يرجى توضيح service classification بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة.","internal_label_en":"service classification","internal_label_ar":"متطلب أغذية ومستلزمات الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Licence/Consent

Ask: Which licensed veterinary/facility scope and owner consent are required? Arabic: يرجى توضيح licence/consent بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة. Reason: licence/consent is required to make Pet food & supplies quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-domain_4","question_en":"Which licensed veterinary/facility scope and owner consent are required?","question_ar":"يرجى توضيح licence/consent بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة.","internal_label_en":"licence/consent","internal_label_ar":"متطلب أغذية ومستلزمات الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Welfare/Care

Ask: What welfare, handling, infection-control, diet and medication procedures apply? Arabic: يرجى توضيح welfare/care بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة. Reason: welfare/care is required to make Pet food & supplies quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-domain_5","question_en":"What welfare, handling, infection-control, diet and medication procedures apply?","question_ar":"يرجى توضيح welfare/care بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة.","internal_label_en":"welfare/care","internal_label_ar":"متطلب أغذية ومستلزمات الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Schedule/Emergency

Ask: What dates, boarding/grooming capacity, emergency and contingency arrangements are required? Arabic: يرجى توضيح schedule/emergency بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة. Reason: schedule/emergency is required to make Pet food & supplies quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-domain_6","question_en":"What dates, boarding/grooming capacity, emergency and contingency arrangements are required?","question_ar":"يرجى توضيح schedule/emergency بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة.","internal_label_en":"schedule/emergency","internal_label_ar":"متطلب أغذية ومستلزمات الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Product/Commercial

Ask: What product registration, batch, expiry, pricing, cancellation and complaint terms apply? Arabic: يرجى توضيح product/commercial بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة. Reason: product/commercial is required to make Pet food & supplies quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-domain_7","question_en":"What product registration, batch, expiry, pricing, cancellation and complaint terms apply?","question_ar":"يرجى توضيح product/commercial بالنسبة إلى أغذية ومستلزمات الحيوانات الأليفة.","internal_label_en":"product/commercial","internal_label_ar":"متطلب أغذية ومستلزمات الحيوانات الأليفة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Pet food & supplies quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Pet food & supplies quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Pet food & supplies quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Pet food & supplies quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Pet food & supplies quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Pet food & supplies quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Pet food & supplies quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Pet food & supplies quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Pet food & supplies quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Pet food & supplies quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Pet food & supplies quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Pet food & supplies quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Pet food & supplies quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Pet food & supplies quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Pet food & supplies quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Pet food & supplies quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Pet food & supplies quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Pet food & supplies quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Pet food & supplies quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Pet food & supplies quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Pet food & supplies quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Pet food & supplies quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"question_id":"q-pet-food-and-supplies-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["animal record","vaccination certificate","microchip/passport record"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Pet food & supplies, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-pet-food-and-supplies-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Pet food & supplies; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Pet food & supplies; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Pet food & supplies; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Pet food & supplies; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Pet food & supplies; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"rule_id":"rule-pet-food-and-supplies-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Pet food & supplies: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Pet food & supplies: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Pet food & supplies: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Pet food & supplies: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Pet food & supplies: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Pet food & supplies: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Pet food & supplies: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Pet food & supplies: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Pet food & supplies: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Pet food & supplies: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"validation_id":"validation-pet-food-and-supplies-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — clinical complexity

Cost driver: clinical complexity. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"clinical complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — animal size/behaviour

Cost driver: animal size/behaviour. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"animal size/behaviour","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — boarding duration

Cost driver: boarding duration. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"boarding duration","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — special diet/medication

Cost driver: special diet/medication. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"special diet/medication","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — emergency coverage

Cost driver: emergency coverage. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"emergency coverage","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — product type and import status

Cost driver: product type and import status. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"product type and import status","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Pet food & supplies quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Pet food & supplies: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Pet food & supplies: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Pet food & supplies: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Pet food & supplies: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Pet food & supplies: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Pet food & supplies: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Pet food & supplies: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Pet food & supplies: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Pet food & supplies: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Pet food & supplies: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — unlicensed veterinary treatment

Risk: unlicensed veterinary treatment. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"unlicensed veterinary treatment","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — missing vaccination

Risk: missing vaccination. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"missing vaccination","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — animal escape/injury

Risk: animal escape/injury. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"animal escape/injury","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — infection outbreak

Risk: infection outbreak. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"infection outbreak","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — wrong food/medication

Risk: wrong food/medication. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"wrong food/medication","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — poor emergency response

Risk: poor emergency response. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"poor emergency response","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Pet food & supplies, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Pet food & supplies: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Pet food & supplies: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Pet food & supplies: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Pet food & supplies: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Pet food & supplies: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Pet food & supplies: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Pet food & supplies, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Pet food & supplies, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Pet food & supplies, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Pet food & supplies, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Pet food & supplies, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Pet food & supplies, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Pet food & supplies, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Pet food & supplies, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Pet food & supplies: vague public request. Input: I need help with Pet food & supplies but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-food-and-supplies-01","input":{"message":"I need help with Pet food & supplies but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Pet food & supplies: minimum quote-ready request. Input: Customer requests Pet food & supplies and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-food-and-supplies-02","input":{"message":"Customer requests Pet food & supplies and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Pet food & supplies: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-food-and-supplies-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Pet food & supplies: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-food-and-supplies-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Pet food & supplies: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-food-and-supplies-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Pet food & supplies: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-food-and-supplies-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Pet food & supplies: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOCCAE-VET, UAE-MOCCAE, UAE-CONSUMER-PROTECTION, UAE-MOIAT-CONFORMITY
- Structured data: `{"scenario_id":"scenario-pet-food-and-supplies-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — microchip

English term: microchip. Arabic operational label: مصطلح microchip ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"microchip","term_ar":"مصطلح microchip ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — vaccination certificate

English term: vaccination certificate. Arabic operational label: مصطلح vaccination certificate ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"vaccination certificate","term_ar":"مصطلح vaccination certificate ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — veterinary prescription

English term: veterinary prescription. Arabic operational label: مصطلح veterinary prescription ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"veterinary prescription","term_ar":"مصطلح veterinary prescription ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — animal welfare

English term: animal welfare. Arabic operational label: مصطلح animal welfare ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"animal welfare","term_ar":"مصطلح animal welfare ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — boarding

English term: boarding. Arabic operational label: مصطلح boarding ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"boarding","term_ar":"مصطلح boarding ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — grooming

English term: grooming. Arabic operational label: مصطلح grooming ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"grooming","term_ar":"مصطلح grooming ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — infection control

English term: infection control. Arabic operational label: مصطلح infection control ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"infection control","term_ar":"مصطلح infection control ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — therapeutic diet

English term: therapeutic diet. Arabic operational label: مصطلح therapeutic diet ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"therapeutic diet","term_ar":"مصطلح therapeutic diet ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — allergy

English term: allergy. Arabic operational label: مصطلح allergy ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"allergy","term_ar":"مصطلح allergy ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — owner consent

English term: owner consent. Arabic operational label: مصطلح owner consent ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"owner consent","term_ar":"مصطلح owner consent ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — quarantine

English term: quarantine. Arabic operational label: مصطلح quarantine ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"quarantine","term_ar":"مصطلح quarantine ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — emergency vet

English term: emergency vet. Arabic operational label: مصطلح emergency vet ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"emergency vet","term_ar":"مصطلح emergency vet ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — batch number

English term: batch number. Arabic operational label: مصطلح batch number ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"batch number","term_ar":"مصطلح batch number ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — expiry

English term: expiry. Arabic operational label: مصطلح expiry ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"expiry","term_ar":"مصطلح expiry ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — species

English term: species. Arabic operational label: مصطلح species ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"species","term_ar":"مصطلح species ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — temperament

English term: temperament. Arabic operational label: مصطلح temperament ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"temperament","term_ar":"مصطلح temperament ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن أغذية ومستلزمات الحيوانات الأليفة. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن أغذية ومستلزمات الحيوانات الأليفة","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Pet food & supplies. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-pet-industry-pet-food-and-supplies-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"pet-food-and-supplies","normalization_only":true}`

