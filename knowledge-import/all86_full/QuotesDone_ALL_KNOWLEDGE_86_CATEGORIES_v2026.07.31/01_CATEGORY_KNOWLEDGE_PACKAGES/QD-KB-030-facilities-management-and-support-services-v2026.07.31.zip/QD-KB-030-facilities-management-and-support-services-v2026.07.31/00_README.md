# QuotesDone Category 30 Knowledge Package

**Category:** Facilities Management & Support Services
**Subcategories:** 8
**Status:** production draft; not SME-approved

Use the numbered JSONL files for programmatic ingestion. `02_category_master.md` is a human-audit view and must not be inserted into every model prompt. The deterministic question, decision-rule and validation files are designed to reduce model use.
