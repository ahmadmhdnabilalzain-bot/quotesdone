# Claude ingestion — Category 63

Import `QD-KB-063-translation-interpretation-and-localization-v2026.07.31` into staging. Read `01_manifest.json`, `21_ingestion_manifest.json`, schema, QA and gaps only. Do not read the master file into context. Stream JSONL files line-by-line, validate locally, upsert by stable IDs, preserve status/source/version and run every scenario. Questions, decision rules and validations belong in relational tables. Narrative records alone require embeddings. Do not promote records to approved without SME sign-off.
