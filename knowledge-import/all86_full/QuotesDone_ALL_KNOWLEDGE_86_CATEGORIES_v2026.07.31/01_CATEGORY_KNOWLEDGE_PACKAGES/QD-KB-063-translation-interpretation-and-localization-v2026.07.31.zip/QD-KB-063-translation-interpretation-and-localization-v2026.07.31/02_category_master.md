# Translation, Interpretation & Localization — Complete Knowledge Master

**Package:** QD-KB-063-translation-interpretation-and-localization-v2026.07.31  
**Arabic:** الترجمة التحريرية والشفوية والتوطين  
**Status:** production draft; not SME/regulatory approved  
**Subcategories:** 3

> This is the human-audit view. Runtime must use atomic JSONL records, deterministic questions/rules and selective retrieval rather than loading this entire file into a prompt.


# 01. Translation services / خدمات الترجمة

**Aliases:** Translation services

## industry — Industry scope — Translation services

Translation services sits within Translation, Interpretation & Localization and covers translation, interpreting and localization services where language pair, purpose, legal certification, subject expertise, source-file control, confidentiality, terminology and quality assurance determine acceptance. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Translation services","aliases_en":["Translation services"],"aliases_ar":["خدمات الترجمة"],"sequence":1}`

## industry — UAE procurement workflow — Translation services

A typical UAE procurement path for Translation services moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Translation services","aliases_en":["Translation services"],"aliases_ar":["خدمات الترجمة"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Translation services

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include translator, legal translator, interpreter, localization engineer, reviewer/proofreader, DTP specialist. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Translation services","aliases_en":["Translation services"],"aliases_ar":["خدمات الترجمة"],"sequence":3}`

## industry — Scope boundaries and escalation — Translation services

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Translation services. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Translation services","aliases_en":["Translation services"],"aliases_ar":["خدمات الترجمة"],"sequence":4}`

## products_services — general translation

general translation is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"general translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — legal translation

legal translation is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"legal translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — certified translation

certified translation is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"certified translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — technical translation

technical translation is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"technical translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — financial translation

financial translation is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"financial translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medical translation

medical translation is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"medical translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — website localization

website localization is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"website localization","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — software/app localization

software/app localization is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"software/app localization","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — subtitling

subtitling is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"subtitling","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — transcreation

transcreation is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"transcreation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — consecutive interpreting

consecutive interpreting is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"consecutive interpreting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — simultaneous interpreting

simultaneous interpreting is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"simultaneous interpreting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — conference interpretation equipment

conference interpretation equipment is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"conference interpretation equipment","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — terminology management

terminology management is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"terminology management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — linguistic quality assurance

linguistic quality assurance is a product or service family relevant to Translation services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"linguistic quality assurance","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — source and target language

Technical topic: source and target language. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"source and target language","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — country/locale

Technical topic: country/locale. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"country/locale","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — purpose and audience

Technical topic: purpose and audience. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"purpose and audience","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — legal/certified status

Technical topic: legal/certified status. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"legal/certified status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — document type and word count

Technical topic: document type and word count. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"document type and word count","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — subject matter

Technical topic: subject matter. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"subject matter","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — source-file format

Technical topic: source-file format. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"source-file format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — layout/DTP

Technical topic: layout/DTP. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"layout/DTP","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — terminology and style

Technical topic: terminology and style. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"terminology and style","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — reference corpus

Technical topic: reference corpus. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"reference corpus","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — interpreter mode

Technical topic: interpreter mode. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"interpreter mode","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — event duration and equipment

Technical topic: event duration and equipment. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"event duration and equipment","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — translator/interpreter qualification

Technical topic: translator/interpreter qualification. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"translator/interpreter qualification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — confidentiality and data handling

Technical topic: confidentiality and data handling. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"confidentiality and data handling","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — review and proofreading

Technical topic: review and proofreading. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"review and proofreading","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — delivery format

Technical topic: delivery format. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"delivery format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — version control

Technical topic: version control. For Translation services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"version control","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — registered legal translator

registered legal translator is a supplier-market role or example for Translation services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"registered legal translator","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — professional translation company

professional translation company is a supplier-market role or example for Translation services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"professional translation company","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — specialist technical translator

specialist technical translator is a supplier-market role or example for Translation services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"specialist technical translator","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — localization agency

localization agency is a supplier-market role or example for Translation services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"localization agency","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — conference-interpreting provider

conference-interpreting provider is a supplier-market role or example for Translation services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"conference-interpreting provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — linguistic QA provider

linguistic QA provider is a supplier-market role or example for Translation services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"linguistic QA provider","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — translator

Supplier type: translator. In Translation services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"translator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — translator

Eligibility gate 1 for a translator responding to Translation services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"translator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — legal translator

Supplier type: legal translator. In Translation services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"legal translator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — legal translator

Eligibility gate 2 for a legal translator responding to Translation services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"legal translator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — interpreter

Supplier type: interpreter. In Translation services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"interpreter","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — interpreter

Eligibility gate 3 for a interpreter responding to Translation services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"interpreter","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — localization engineer

Supplier type: localization engineer. In Translation services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"localization engineer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — localization engineer

Eligibility gate 4 for a localization engineer responding to Translation services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"localization engineer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — reviewer/proofreader

Supplier type: reviewer/proofreader. In Translation services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"reviewer/proofreader","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — reviewer/proofreader

Eligibility gate 5 for a reviewer/proofreader responding to Translation services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"reviewer/proofreader","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — DTP specialist

Supplier type: DTP specialist. In Translation services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"DTP specialist","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — DTP specialist

Eligibility gate 6 for a DTP specialist responding to Translation services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"DTP specialist","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — equipment provider

Supplier type: equipment provider. In Translation services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"equipment provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — equipment provider

Eligibility gate 7 for a equipment provider responding to Translation services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"equipment provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — project manager

Supplier type: project manager. In Translation services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"project manager","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — project manager

Eligibility gate 8 for a project manager responding to Translation services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"project manager","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — language pair/locale

Quotation requirement: language pair/locale. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"language_pair_locale","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — purpose/certification

Quotation requirement: purpose/certification. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"purpose_certification","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — volume/files

Quotation requirement: volume/files. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"volume_files","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — subject expertise

Quotation requirement: subject expertise. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"subject_expertise","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — terminology/style

Quotation requirement: terminology/style. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"terminology_style","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — format/DTP

Quotation requirement: format/DTP. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"format_dtp","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — interpreting logistics

Quotation requirement: interpreting logistics. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"interpreting_logistics","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — confidentiality

Quotation requirement: confidentiality. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"confidentiality","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — QA/revision

Quotation requirement: QA/revision. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"qa_revision","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — delivery/deadline

Quotation requirement: delivery/deadline. Every supplier response for Translation services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"delivery_deadline","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — source files

Document: source files. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"source_files","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — word/page count

Document: word/page count. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"word_page_count","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — language/locale matrix

Document: language/locale matrix. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"language_locale_matrix","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — certification requirement

Document: certification requirement. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"certification_requirement","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — terminology/glossary

Document: terminology/glossary. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"terminology_glossary","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — style guide

Document: style guide. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"style_guide","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — reference translation

Document: reference translation. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"reference_translation","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — layout sample

Document: layout sample. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"layout_sample","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — event agenda

Document: event agenda. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"event_agenda","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — speaker list

Document: speaker list. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"speaker_list","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — interpreting equipment plan

Document: interpreting equipment plan. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"interpreting_equipment_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — NDA/data requirement

Document: NDA/data requirement. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"nda_data_requirement","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — QA checklist

Document: QA checklist. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"qa_checklist","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — delivery/version schedule

Document: delivery/version schedule. For Translation services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"delivery_version_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Registration of Legal Translator

Source activation for Translation services: Registration of Legal Translator (UAE Ministry of Justice). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current registration, language, qualification, renewal and professional requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR
- Structured data: `{"source_id":"UAE-MOJ-TRANSLATOR","publisher":"UAE Ministry of Justice","url":"https://www.moj.gov.ae/en/services/services-categories/general/registration-of-legal-translator-a9314f86.aspx","source_type":"government_legal_profession_service","live_verification":true}`

## uae_regulations — Document Attestation Services

Source activation for Translation services: Document Attestation Services (UAE Ministry of Foreign Affairs). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify document origin, destination, legalization chain and current service requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOFA-ATTESTATION
- Structured data: `{"source_id":"UAE-MOFA-ATTESTATION","publisher":"UAE Ministry of Foreign Affairs","url":"https://www.mofa.gov.ae/en/services/attestation","source_type":"government_attestation_service","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Translation services: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Translation services: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Translation services: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Translation services: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Registration of Legal Translator

Source activation for Translation services: Registration of Legal Translator (UAE Ministry of Justice). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current registration, language, qualification, renewal and professional requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR
- Structured data: `{"source_id":"UAE-MOJ-TRANSLATOR","publisher":"UAE Ministry of Justice","url":"https://www.moj.gov.ae/en/services/services-categories/general/registration-of-legal-translator-a9314f86.aspx","source_type":"government_legal_profession_service","live_verification":true}`

## uae_regulations — Document Attestation Services

Source activation for Translation services: Document Attestation Services (UAE Ministry of Foreign Affairs). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify document origin, destination, legalization chain and current service requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOFA-ATTESTATION
- Structured data: `{"source_id":"UAE-MOFA-ATTESTATION","publisher":"UAE Ministry of Foreign Affairs","url":"https://www.mofa.gov.ae/en/services/attestation","source_type":"government_attestation_service","live_verification":true}`

## inquiry_qualification — Language/Service

Ask: What source/target languages, locale and exact service are required? Arabic: يرجى توضيح language/service بالنسبة إلى خدمات الترجمة. Reason: language/service is required to make Translation services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-domain_1","question_en":"What source/target languages, locale and exact service are required?","question_ar":"يرجى توضيح language/service بالنسبة إلى خدمات الترجمة.","internal_label_en":"language/service","internal_label_ar":"متطلب خدمات الترجمة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Purpose/Subject

Ask: What is the document/content/event purpose, audience and subject matter? Arabic: يرجى توضيح purpose/subject بالنسبة إلى خدمات الترجمة. Reason: purpose/subject is required to make Translation services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-domain_2","question_en":"What is the document/content/event purpose, audience and subject matter?","question_ar":"يرجى توضيح purpose/subject بالنسبة إلى خدمات الترجمة.","internal_label_en":"purpose/subject","internal_label_ar":"متطلب خدمات الترجمة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Certification

Ask: Is legal certification, attestation, sworn/legal translator status or authority acceptance required? Arabic: يرجى توضيح certification بالنسبة إلى خدمات الترجمة. Reason: certification is required to make Translation services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-domain_3","question_en":"Is legal certification, attestation, sworn/legal translator status or authority acceptance required?","question_ar":"يرجى توضيح certification بالنسبة إلى خدمات الترجمة.","internal_label_en":"certification","internal_label_ar":"متطلب خدمات الترجمة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Volume/Format

Ask: What files, word/page/minute volume, format, layout and version-control requirements apply? Arabic: يرجى توضيح volume/format بالنسبة إلى خدمات الترجمة. Reason: volume/format is required to make Translation services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-domain_4","question_en":"What files, word/page/minute volume, format, layout and version-control requirements apply?","question_ar":"يرجى توضيح volume/format بالنسبة إلى خدمات الترجمة.","internal_label_en":"volume/format","internal_label_ar":"متطلب خدمات الترجمة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Terminology/Style

Ask: What terminology, style guide, references, translation memory and subject expertise are required? Arabic: يرجى توضيح terminology/style بالنسبة إلى خدمات الترجمة. Reason: terminology/style is required to make Translation services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-domain_5","question_en":"What terminology, style guide, references, translation memory and subject expertise are required?","question_ar":"يرجى توضيح terminology/style بالنسبة إلى خدمات الترجمة.","internal_label_en":"terminology/style","internal_label_ar":"متطلب خدمات الترجمة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Interpreting Logistics

Ask: For interpretation, what mode, dates, venue, speakers, booths/equipment and recording needs apply? Arabic: يرجى توضيح interpreting logistics بالنسبة إلى خدمات الترجمة. Reason: interpreting logistics is required to make Translation services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-domain_6","question_en":"For interpretation, what mode, dates, venue, speakers, booths/equipment and recording needs apply?","question_ar":"يرجى توضيح interpreting logistics بالنسبة إلى خدمات الترجمة.","internal_label_en":"interpreting logistics","internal_label_ar":"متطلب خدمات الترجمة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Confidentiality/Qa

Ask: What confidentiality, QA, proofreading, revision, delivery and acceptance terms apply? Arabic: يرجى توضيح confidentiality/QA بالنسبة إلى خدمات الترجمة. Reason: confidentiality/QA is required to make Translation services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-domain_7","question_en":"What confidentiality, QA, proofreading, revision, delivery and acceptance terms apply?","question_ar":"يرجى توضيح confidentiality/QA بالنسبة إلى خدمات الترجمة.","internal_label_en":"confidentiality/QA","internal_label_ar":"متطلب خدمات الترجمة","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Translation services quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Translation services quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Translation services quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Translation services quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Translation services quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Translation services quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Translation services quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Translation services quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Translation services quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Translation services quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Translation services quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Translation services quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Translation services quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Translation services quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Translation services quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Translation services quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Translation services quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Translation services quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Translation services quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Translation services quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Translation services quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Translation services quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-translation-services-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Translation services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-translation-services-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-translation-services-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Translation services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-translation-services-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Translation services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-translation-services-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Translation services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-translation-services-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Translation services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-translation-services-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Translation services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-translation-services-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Translation services: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-translation-services-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Translation services: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-translation-services-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Translation services: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-translation-services-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Translation services: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"validation_id":"validation-translation-services-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Translation services: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-translation-services-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Translation services: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-translation-services-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Translation services: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"validation_id":"validation-translation-services-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Translation services: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-translation-services-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Translation services: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-translation-services-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Translation services: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"validation_id":"validation-translation-services-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — language pair and scarcity

Cost driver: language pair and scarcity. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"language pair and scarcity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — legal certification

Cost driver: legal certification. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"legal certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — volume and urgency

Cost driver: volume and urgency. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"volume and urgency","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — technical specialization

Cost driver: technical specialization. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"technical specialization","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — layout/localization complexity

Cost driver: layout/localization complexity. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"layout/localization complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — interpreting equipment and staffing

Cost driver: interpreting equipment and staffing. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"interpreting equipment and staffing","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Translation services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Translation services: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Translation services: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Translation services: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Translation services: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Translation services: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Translation services: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Translation services: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Translation services: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Translation services: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Translation services: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — wrong language/locale

Risk: wrong language/locale. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"wrong language/locale","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unqualified legal translation

Risk: unqualified legal translation. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"unqualified legal translation","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — meaning or numeric error

Risk: meaning or numeric error. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"meaning or numeric error","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — confidentiality breach

Risk: confidentiality breach. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"confidentiality breach","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — format/version mismatch

Risk: format/version mismatch. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"format/version mismatch","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — insufficient interpreter capacity

Risk: insufficient interpreter capacity. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"insufficient interpreter capacity","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Translation services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Translation services: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Translation services: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Translation services: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Translation services: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Translation services: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Translation services: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Translation services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Translation services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Translation services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Translation services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Translation services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Translation services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Translation services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Translation services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Translation services: vague public request. Input: I need help with Translation services but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-translation-services-01","input":{"message":"I need help with Translation services but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Translation services: minimum quote-ready request. Input: Customer requests Translation services and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-translation-services-02","input":{"message":"Customer requests Translation services and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Translation services: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-translation-services-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Translation services: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-translation-services-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Translation services: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-translation-services-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Translation services: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-translation-services-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Translation services: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-translation-services-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — source language

English term: source language. Arabic operational label: مصطلح source language ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"source language","term_ar":"مصطلح source language ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — target language

English term: target language. Arabic operational label: مصطلح target language ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"target language","term_ar":"مصطلح target language ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — locale

English term: locale. Arabic operational label: مصطلح locale ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"locale","term_ar":"مصطلح locale ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — legal translation

English term: legal translation. Arabic operational label: مصطلح legal translation ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"legal translation","term_ar":"مصطلح legal translation ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — certified translation

English term: certified translation. Arabic operational label: مصطلح certified translation ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certified translation","term_ar":"مصطلح certified translation ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — attestation

English term: attestation. Arabic operational label: مصطلح attestation ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"attestation","term_ar":"مصطلح attestation ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — consecutive interpretation

English term: consecutive interpretation. Arabic operational label: مصطلح consecutive interpretation ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"consecutive interpretation","term_ar":"مصطلح consecutive interpretation ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — simultaneous interpretation

English term: simultaneous interpretation. Arabic operational label: مصطلح simultaneous interpretation ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"simultaneous interpretation","term_ar":"مصطلح simultaneous interpretation ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — translation memory

English term: translation memory. Arabic operational label: مصطلح translation memory ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"translation memory","term_ar":"مصطلح translation memory ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — terminology base

English term: terminology base. Arabic operational label: مصطلح terminology base ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"terminology base","term_ar":"مصطلح terminology base ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — localization

English term: localization. Arabic operational label: مصطلح localization ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"localization","term_ar":"مصطلح localization ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — DTP

English term: DTP. Arabic operational label: مصطلح DTP ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"DTP","term_ar":"مصطلح DTP ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — subtitling

English term: subtitling. Arabic operational label: مصطلح subtitling ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"subtitling","term_ar":"مصطلح subtitling ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — proofreading

English term: proofreading. Arabic operational label: مصطلح proofreading ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"proofreading","term_ar":"مصطلح proofreading ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — back translation

English term: back translation. Arabic operational label: مصطلح back translation ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"back translation","term_ar":"مصطلح back translation ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — NDA

English term: NDA. Arabic operational label: مصطلح NDA ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"NDA","term_ar":"مصطلح NDA ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن خدمات الترجمة. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن خدمات الترجمة","canonical_subcategory":"translation-services","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Translation services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-translation-services-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"translation-services","normalization_only":true}`


# 02. Interpretation & simultaneous translation / الترجمة الشفوية والفورية

**Aliases:** Interpretation & simultaneous translation, conference interpreting, simultaneous interpreting, oral translation, Interpretation, simultaneous translation

## industry — Industry scope — Interpretation & simultaneous translation

Interpretation & simultaneous translation sits within Translation, Interpretation & Localization and covers translation, interpreting and localization services where language pair, purpose, legal certification, subject expertise, source-file control, confidentiality, terminology and quality assurance determine acceptance. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Interpretation & simultaneous translation","aliases_en":["Interpretation & simultaneous translation","conference interpreting","simultaneous interpreting","oral translation","Interpretation","simultaneous translation"],"aliases_ar":["الترجمة الشفوية والفورية"],"sequence":1}`

## industry — UAE procurement workflow — Interpretation & simultaneous translation

A typical UAE procurement path for Interpretation & simultaneous translation moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Interpretation & simultaneous translation","aliases_en":["Interpretation & simultaneous translation","conference interpreting","simultaneous interpreting","oral translation","Interpretation","simultaneous translation"],"aliases_ar":["الترجمة الشفوية والفورية"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Interpretation & simultaneous translation

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include translator, legal translator, interpreter, localization engineer, reviewer/proofreader, DTP specialist. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Interpretation & simultaneous translation","aliases_en":["Interpretation & simultaneous translation","conference interpreting","simultaneous interpreting","oral translation","Interpretation","simultaneous translation"],"aliases_ar":["الترجمة الشفوية والفورية"],"sequence":3}`

## industry — Scope boundaries and escalation — Interpretation & simultaneous translation

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Interpretation & simultaneous translation. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Interpretation & simultaneous translation","aliases_en":["Interpretation & simultaneous translation","conference interpreting","simultaneous interpreting","oral translation","Interpretation","simultaneous translation"],"aliases_ar":["الترجمة الشفوية والفورية"],"sequence":4}`

## products_services — general translation

general translation is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"general translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — legal translation

legal translation is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"legal translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — certified translation

certified translation is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"certified translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — technical translation

technical translation is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"technical translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — financial translation

financial translation is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"financial translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medical translation

medical translation is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"medical translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — website localization

website localization is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"website localization","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — software/app localization

software/app localization is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"software/app localization","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — subtitling

subtitling is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"subtitling","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — transcreation

transcreation is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"transcreation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — consecutive interpreting

consecutive interpreting is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"consecutive interpreting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — simultaneous interpreting

simultaneous interpreting is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"simultaneous interpreting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — conference interpretation equipment

conference interpretation equipment is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"conference interpretation equipment","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — terminology management

terminology management is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"terminology management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — linguistic quality assurance

linguistic quality assurance is a product or service family relevant to Interpretation & simultaneous translation. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"linguistic quality assurance","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — source and target language

Technical topic: source and target language. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"source and target language","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — country/locale

Technical topic: country/locale. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"country/locale","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — purpose and audience

Technical topic: purpose and audience. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"purpose and audience","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — legal/certified status

Technical topic: legal/certified status. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"legal/certified status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — document type and word count

Technical topic: document type and word count. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"document type and word count","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — subject matter

Technical topic: subject matter. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"subject matter","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — source-file format

Technical topic: source-file format. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"source-file format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — layout/DTP

Technical topic: layout/DTP. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"layout/DTP","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — terminology and style

Technical topic: terminology and style. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"terminology and style","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — reference corpus

Technical topic: reference corpus. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"reference corpus","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — interpreter mode

Technical topic: interpreter mode. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"interpreter mode","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — event duration and equipment

Technical topic: event duration and equipment. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"event duration and equipment","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — translator/interpreter qualification

Technical topic: translator/interpreter qualification. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"translator/interpreter qualification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — confidentiality and data handling

Technical topic: confidentiality and data handling. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"confidentiality and data handling","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — review and proofreading

Technical topic: review and proofreading. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"review and proofreading","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — delivery format

Technical topic: delivery format. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"delivery format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — version control

Technical topic: version control. For Interpretation & simultaneous translation, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"version control","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — registered legal translator

registered legal translator is a supplier-market role or example for Interpretation & simultaneous translation; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"registered legal translator","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — professional translation company

professional translation company is a supplier-market role or example for Interpretation & simultaneous translation; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"professional translation company","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — specialist technical translator

specialist technical translator is a supplier-market role or example for Interpretation & simultaneous translation; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"specialist technical translator","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — localization agency

localization agency is a supplier-market role or example for Interpretation & simultaneous translation; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"localization agency","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — conference-interpreting provider

conference-interpreting provider is a supplier-market role or example for Interpretation & simultaneous translation; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"conference-interpreting provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — linguistic QA provider

linguistic QA provider is a supplier-market role or example for Interpretation & simultaneous translation; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"linguistic QA provider","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — translator

Supplier type: translator. In Interpretation & simultaneous translation, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"translator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — translator

Eligibility gate 1 for a translator responding to Interpretation & simultaneous translation: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"translator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — legal translator

Supplier type: legal translator. In Interpretation & simultaneous translation, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"legal translator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — legal translator

Eligibility gate 2 for a legal translator responding to Interpretation & simultaneous translation: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"legal translator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — interpreter

Supplier type: interpreter. In Interpretation & simultaneous translation, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"interpreter","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — interpreter

Eligibility gate 3 for a interpreter responding to Interpretation & simultaneous translation: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"interpreter","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — localization engineer

Supplier type: localization engineer. In Interpretation & simultaneous translation, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"localization engineer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — localization engineer

Eligibility gate 4 for a localization engineer responding to Interpretation & simultaneous translation: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"localization engineer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — reviewer/proofreader

Supplier type: reviewer/proofreader. In Interpretation & simultaneous translation, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"reviewer/proofreader","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — reviewer/proofreader

Eligibility gate 5 for a reviewer/proofreader responding to Interpretation & simultaneous translation: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"reviewer/proofreader","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — DTP specialist

Supplier type: DTP specialist. In Interpretation & simultaneous translation, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"DTP specialist","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — DTP specialist

Eligibility gate 6 for a DTP specialist responding to Interpretation & simultaneous translation: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"DTP specialist","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — equipment provider

Supplier type: equipment provider. In Interpretation & simultaneous translation, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"equipment provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — equipment provider

Eligibility gate 7 for a equipment provider responding to Interpretation & simultaneous translation: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"equipment provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — project manager

Supplier type: project manager. In Interpretation & simultaneous translation, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"project manager","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — project manager

Eligibility gate 8 for a project manager responding to Interpretation & simultaneous translation: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"project manager","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — language pair/locale

Quotation requirement: language pair/locale. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"language_pair_locale","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — purpose/certification

Quotation requirement: purpose/certification. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"purpose_certification","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — volume/files

Quotation requirement: volume/files. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"volume_files","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — subject expertise

Quotation requirement: subject expertise. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"subject_expertise","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — terminology/style

Quotation requirement: terminology/style. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"terminology_style","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — format/DTP

Quotation requirement: format/DTP. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"format_dtp","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — interpreting logistics

Quotation requirement: interpreting logistics. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"interpreting_logistics","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — confidentiality

Quotation requirement: confidentiality. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"confidentiality","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — QA/revision

Quotation requirement: QA/revision. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"qa_revision","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — delivery/deadline

Quotation requirement: delivery/deadline. Every supplier response for Interpretation & simultaneous translation should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"delivery_deadline","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — source files

Document: source files. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"source_files","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — word/page count

Document: word/page count. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"word_page_count","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — language/locale matrix

Document: language/locale matrix. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"language_locale_matrix","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — certification requirement

Document: certification requirement. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"certification_requirement","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — terminology/glossary

Document: terminology/glossary. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"terminology_glossary","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — style guide

Document: style guide. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"style_guide","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — reference translation

Document: reference translation. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"reference_translation","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — layout sample

Document: layout sample. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"layout_sample","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — event agenda

Document: event agenda. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"event_agenda","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — speaker list

Document: speaker list. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"speaker_list","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — interpreting equipment plan

Document: interpreting equipment plan. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"interpreting_equipment_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — NDA/data requirement

Document: NDA/data requirement. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"nda_data_requirement","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — QA checklist

Document: QA checklist. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"qa_checklist","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — delivery/version schedule

Document: delivery/version schedule. For Interpretation & simultaneous translation, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"delivery_version_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Registration of Legal Translator

Source activation for Interpretation & simultaneous translation: Registration of Legal Translator (UAE Ministry of Justice). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current registration, language, qualification, renewal and professional requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR
- Structured data: `{"source_id":"UAE-MOJ-TRANSLATOR","publisher":"UAE Ministry of Justice","url":"https://www.moj.gov.ae/en/services/services-categories/general/registration-of-legal-translator-a9314f86.aspx","source_type":"government_legal_profession_service","live_verification":true}`

## uae_regulations — Document Attestation Services

Source activation for Interpretation & simultaneous translation: Document Attestation Services (UAE Ministry of Foreign Affairs). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify document origin, destination, legalization chain and current service requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOFA-ATTESTATION
- Structured data: `{"source_id":"UAE-MOFA-ATTESTATION","publisher":"UAE Ministry of Foreign Affairs","url":"https://www.mofa.gov.ae/en/services/attestation","source_type":"government_attestation_service","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Interpretation & simultaneous translation: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Interpretation & simultaneous translation: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Interpretation & simultaneous translation: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Interpretation & simultaneous translation: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Registration of Legal Translator

Source activation for Interpretation & simultaneous translation: Registration of Legal Translator (UAE Ministry of Justice). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current registration, language, qualification, renewal and professional requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR
- Structured data: `{"source_id":"UAE-MOJ-TRANSLATOR","publisher":"UAE Ministry of Justice","url":"https://www.moj.gov.ae/en/services/services-categories/general/registration-of-legal-translator-a9314f86.aspx","source_type":"government_legal_profession_service","live_verification":true}`

## uae_regulations — Document Attestation Services

Source activation for Interpretation & simultaneous translation: Document Attestation Services (UAE Ministry of Foreign Affairs). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify document origin, destination, legalization chain and current service requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOFA-ATTESTATION
- Structured data: `{"source_id":"UAE-MOFA-ATTESTATION","publisher":"UAE Ministry of Foreign Affairs","url":"https://www.mofa.gov.ae/en/services/attestation","source_type":"government_attestation_service","live_verification":true}`

## inquiry_qualification — Language/Service

Ask: What source/target languages, locale and exact service are required? Arabic: يرجى توضيح language/service بالنسبة إلى الترجمة الشفوية والفورية. Reason: language/service is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-domain_1","question_en":"What source/target languages, locale and exact service are required?","question_ar":"يرجى توضيح language/service بالنسبة إلى الترجمة الشفوية والفورية.","internal_label_en":"language/service","internal_label_ar":"متطلب الترجمة الشفوية والفورية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Purpose/Subject

Ask: What is the document/content/event purpose, audience and subject matter? Arabic: يرجى توضيح purpose/subject بالنسبة إلى الترجمة الشفوية والفورية. Reason: purpose/subject is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-domain_2","question_en":"What is the document/content/event purpose, audience and subject matter?","question_ar":"يرجى توضيح purpose/subject بالنسبة إلى الترجمة الشفوية والفورية.","internal_label_en":"purpose/subject","internal_label_ar":"متطلب الترجمة الشفوية والفورية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Certification

Ask: Is legal certification, attestation, sworn/legal translator status or authority acceptance required? Arabic: يرجى توضيح certification بالنسبة إلى الترجمة الشفوية والفورية. Reason: certification is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-domain_3","question_en":"Is legal certification, attestation, sworn/legal translator status or authority acceptance required?","question_ar":"يرجى توضيح certification بالنسبة إلى الترجمة الشفوية والفورية.","internal_label_en":"certification","internal_label_ar":"متطلب الترجمة الشفوية والفورية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Volume/Format

Ask: What files, word/page/minute volume, format, layout and version-control requirements apply? Arabic: يرجى توضيح volume/format بالنسبة إلى الترجمة الشفوية والفورية. Reason: volume/format is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-domain_4","question_en":"What files, word/page/minute volume, format, layout and version-control requirements apply?","question_ar":"يرجى توضيح volume/format بالنسبة إلى الترجمة الشفوية والفورية.","internal_label_en":"volume/format","internal_label_ar":"متطلب الترجمة الشفوية والفورية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Terminology/Style

Ask: What terminology, style guide, references, translation memory and subject expertise are required? Arabic: يرجى توضيح terminology/style بالنسبة إلى الترجمة الشفوية والفورية. Reason: terminology/style is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-domain_5","question_en":"What terminology, style guide, references, translation memory and subject expertise are required?","question_ar":"يرجى توضيح terminology/style بالنسبة إلى الترجمة الشفوية والفورية.","internal_label_en":"terminology/style","internal_label_ar":"متطلب الترجمة الشفوية والفورية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Interpreting Logistics

Ask: For interpretation, what mode, dates, venue, speakers, booths/equipment and recording needs apply? Arabic: يرجى توضيح interpreting logistics بالنسبة إلى الترجمة الشفوية والفورية. Reason: interpreting logistics is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-domain_6","question_en":"For interpretation, what mode, dates, venue, speakers, booths/equipment and recording needs apply?","question_ar":"يرجى توضيح interpreting logistics بالنسبة إلى الترجمة الشفوية والفورية.","internal_label_en":"interpreting logistics","internal_label_ar":"متطلب الترجمة الشفوية والفورية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Confidentiality/Qa

Ask: What confidentiality, QA, proofreading, revision, delivery and acceptance terms apply? Arabic: يرجى توضيح confidentiality/QA بالنسبة إلى الترجمة الشفوية والفورية. Reason: confidentiality/QA is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-domain_7","question_en":"What confidentiality, QA, proofreading, revision, delivery and acceptance terms apply?","question_ar":"يرجى توضيح confidentiality/QA بالنسبة إلى الترجمة الشفوية والفورية.","internal_label_en":"confidentiality/QA","internal_label_ar":"متطلب الترجمة الشفوية والفورية","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Interpretation & simultaneous translation quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-interpretation-and-simultaneous-translation-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Interpretation & simultaneous translation, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-interpretation-and-simultaneous-translation-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Interpretation & simultaneous translation; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Interpretation & simultaneous translation; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Interpretation & simultaneous translation; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Interpretation & simultaneous translation; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Interpretation & simultaneous translation; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-interpretation-and-simultaneous-translation-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Interpretation & simultaneous translation: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Interpretation & simultaneous translation: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Interpretation & simultaneous translation: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Interpretation & simultaneous translation: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Interpretation & simultaneous translation: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Interpretation & simultaneous translation: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Interpretation & simultaneous translation: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Interpretation & simultaneous translation: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Interpretation & simultaneous translation: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Interpretation & simultaneous translation: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"validation_id":"validation-interpretation-and-simultaneous-translation-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — language pair and scarcity

Cost driver: language pair and scarcity. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"language pair and scarcity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — legal certification

Cost driver: legal certification. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"legal certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — volume and urgency

Cost driver: volume and urgency. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"volume and urgency","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — technical specialization

Cost driver: technical specialization. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"technical specialization","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — layout/localization complexity

Cost driver: layout/localization complexity. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"layout/localization complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — interpreting equipment and staffing

Cost driver: interpreting equipment and staffing. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"interpreting equipment and staffing","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Interpretation & simultaneous translation quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Interpretation & simultaneous translation: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Interpretation & simultaneous translation: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Interpretation & simultaneous translation: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Interpretation & simultaneous translation: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Interpretation & simultaneous translation: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Interpretation & simultaneous translation: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Interpretation & simultaneous translation: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Interpretation & simultaneous translation: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Interpretation & simultaneous translation: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Interpretation & simultaneous translation: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — wrong language/locale

Risk: wrong language/locale. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"wrong language/locale","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unqualified legal translation

Risk: unqualified legal translation. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"unqualified legal translation","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — meaning or numeric error

Risk: meaning or numeric error. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"meaning or numeric error","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — confidentiality breach

Risk: confidentiality breach. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"confidentiality breach","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — format/version mismatch

Risk: format/version mismatch. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"format/version mismatch","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — insufficient interpreter capacity

Risk: insufficient interpreter capacity. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"insufficient interpreter capacity","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Interpretation & simultaneous translation, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Interpretation & simultaneous translation: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Interpretation & simultaneous translation: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Interpretation & simultaneous translation: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Interpretation & simultaneous translation: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Interpretation & simultaneous translation: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Interpretation & simultaneous translation: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Interpretation & simultaneous translation, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Interpretation & simultaneous translation, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Interpretation & simultaneous translation, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Interpretation & simultaneous translation, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Interpretation & simultaneous translation, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Interpretation & simultaneous translation, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Interpretation & simultaneous translation, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Interpretation & simultaneous translation, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Interpretation & simultaneous translation: vague public request. Input: I need help with Interpretation & simultaneous translation but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-interpretation-and-simultaneous-translation-01","input":{"message":"I need help with Interpretation & simultaneous translation but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Interpretation & simultaneous translation: minimum quote-ready request. Input: Customer requests Interpretation & simultaneous translation and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-interpretation-and-simultaneous-translation-02","input":{"message":"Customer requests Interpretation & simultaneous translation and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Interpretation & simultaneous translation: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-interpretation-and-simultaneous-translation-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Interpretation & simultaneous translation: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-interpretation-and-simultaneous-translation-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Interpretation & simultaneous translation: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-interpretation-and-simultaneous-translation-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Interpretation & simultaneous translation: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-interpretation-and-simultaneous-translation-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Interpretation & simultaneous translation: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-interpretation-and-simultaneous-translation-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — source language

English term: source language. Arabic operational label: مصطلح source language ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"source language","term_ar":"مصطلح source language ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — target language

English term: target language. Arabic operational label: مصطلح target language ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"target language","term_ar":"مصطلح target language ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — locale

English term: locale. Arabic operational label: مصطلح locale ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"locale","term_ar":"مصطلح locale ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — legal translation

English term: legal translation. Arabic operational label: مصطلح legal translation ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"legal translation","term_ar":"مصطلح legal translation ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — certified translation

English term: certified translation. Arabic operational label: مصطلح certified translation ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certified translation","term_ar":"مصطلح certified translation ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — attestation

English term: attestation. Arabic operational label: مصطلح attestation ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"attestation","term_ar":"مصطلح attestation ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — consecutive interpretation

English term: consecutive interpretation. Arabic operational label: مصطلح consecutive interpretation ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"consecutive interpretation","term_ar":"مصطلح consecutive interpretation ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — simultaneous interpretation

English term: simultaneous interpretation. Arabic operational label: مصطلح simultaneous interpretation ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"simultaneous interpretation","term_ar":"مصطلح simultaneous interpretation ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — translation memory

English term: translation memory. Arabic operational label: مصطلح translation memory ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"translation memory","term_ar":"مصطلح translation memory ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — terminology base

English term: terminology base. Arabic operational label: مصطلح terminology base ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"terminology base","term_ar":"مصطلح terminology base ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — localization

English term: localization. Arabic operational label: مصطلح localization ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"localization","term_ar":"مصطلح localization ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — DTP

English term: DTP. Arabic operational label: مصطلح DTP ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"DTP","term_ar":"مصطلح DTP ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — subtitling

English term: subtitling. Arabic operational label: مصطلح subtitling ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"subtitling","term_ar":"مصطلح subtitling ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — proofreading

English term: proofreading. Arabic operational label: مصطلح proofreading ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"proofreading","term_ar":"مصطلح proofreading ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — back translation

English term: back translation. Arabic operational label: مصطلح back translation ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"back translation","term_ar":"مصطلح back translation ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — NDA

English term: NDA. Arabic operational label: مصطلح NDA ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"NDA","term_ar":"مصطلح NDA ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن الترجمة الشفوية والفورية. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن الترجمة الشفوية والفورية","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Interpretation & simultaneous translation. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-interpretation-and-simultaneous-translation-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"interpretation-and-simultaneous-translation","normalization_only":true}`


# 03. Localization services / خدمات التوطين اللغوي

**Aliases:** Localization services

## industry — Industry scope — Localization services

Localization services sits within Translation, Interpretation & Localization and covers translation, interpreting and localization services where language pair, purpose, legal certification, subject expertise, source-file control, confidentiality, terminology and quality assurance determine acceptance. The inquiry router should normalize informal customer wording to this subcategory only when the intended use, requested output and supporting evidence fit. It must preserve alternative candidates when the request overlaps another category. The category agent then collects quote-critical information rather than attempting professional design or authority interpretation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-industry-subcategory_overview-001`
- Type: `subcategory_overview`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Localization services","aliases_en":["Localization services"],"aliases_ar":["خدمات التوطين اللغوي"],"sequence":1}`

## industry — UAE procurement workflow — Localization services

A typical UAE procurement path for Localization services moves from a plain-language need to classification, scope confirmation, supplier prequalification, technical and regulatory review, comparable quotation, clarification, award, execution, inspection and handover. The platform should distinguish budget requests from approved procurement and retain document versions, assumptions, exclusions and source lineage at every stage.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-industry-market_workflow-002`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Localization services","aliases_en":["Localization services"],"aliases_ar":["خدمات التوطين اللغوي"],"sequence":2}`

## industry — Buyer and supplier ecosystem — Localization services

Typical buyers may include developers, asset owners, contractors, operators, government entities, SMEs and private customers. Relevant suppliers can include translator, legal translator, interpreter, localization engineer, reviewer/proofreader, DTP specialist. Matching should rely on verified capability, jurisdiction, authorization, service coverage, response performance and the exact subcategory—not broad marketing claims.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-industry-market_workflow-003`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Localization services","aliases_en":["Localization services"],"aliases_ar":["خدمات التوطين اللغوي"],"sequence":3}`

## industry — Scope boundaries and escalation — Localization services

The knowledge pack supports routing, inquiry qualification, document requirements, supplier comparison and controlled retrieval for Localization services. It does not automatically approve engineering design, medical or legal advice, regulated professional judgment, safety certification or authority acceptance. Conflicts, novel conditions and low-confidence classification must be held and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-industry-market_workflow-004`
- Type: `market_workflow`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"subcategory":"Localization services","aliases_en":["Localization services"],"aliases_ar":["خدمات التوطين اللغوي"],"sequence":4}`

## products_services — general translation

general translation is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-001`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"general translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — legal translation

legal translation is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-002`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"legal translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — certified translation

certified translation is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-003`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"certified translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — technical translation

technical translation is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-004`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"technical translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — financial translation

financial translation is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-005`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"financial translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — medical translation

medical translation is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-006`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"medical translation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — website localization

website localization is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-007`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"website localization","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — software/app localization

software/app localization is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-008`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"software/app localization","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — subtitling

subtitling is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-009`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"subtitling","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — transcreation

transcreation is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-010`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"transcreation","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — consecutive interpreting

consecutive interpreting is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-011`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"consecutive interpreting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — simultaneous interpreting

simultaneous interpreting is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-012`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"simultaneous interpreting","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — conference interpretation equipment

conference interpretation equipment is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-013`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"conference interpretation equipment","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — terminology management

terminology management is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-014`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"terminology management","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## products_services — linguistic quality assurance

linguistic quality assurance is a product or service family relevant to Localization services. Qualification must establish the intended use, quantity, performance basis, material or configuration, compatibility, delivery form, installation responsibility, required evidence, warranty and lifecycle support. A family name is not proof of an exact grade, model, certification or availability; suppliers must identify the offered item and disclose deviations from the governing brief.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-products_services-product_service_family-015`
- Type: `product_service_family`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"family":"linguistic quality assurance","classification_only":true,"fields":["intended_use","quantity","specification","compatibility","scope","evidence","warranty"]}`

## technical — source and target language

Technical topic: source and target language. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-001`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"source and target language","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — country/locale

Technical topic: country/locale. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-002`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"country/locale","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — purpose and audience

Technical topic: purpose and audience. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-003`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"purpose and audience","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — legal/certified status

Technical topic: legal/certified status. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-004`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"legal/certified status","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — document type and word count

Technical topic: document type and word count. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-005`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"document type and word count","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — subject matter

Technical topic: subject matter. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-006`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"subject matter","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — source-file format

Technical topic: source-file format. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-007`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"source-file format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — layout/DTP

Technical topic: layout/DTP. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-008`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"layout/DTP","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — terminology and style

Technical topic: terminology and style. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-009`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"terminology and style","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — reference corpus

Technical topic: reference corpus. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-010`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"reference corpus","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — interpreter mode

Technical topic: interpreter mode. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-011`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"interpreter mode","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — event duration and equipment

Technical topic: event duration and equipment. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-012`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"event duration and equipment","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — translator/interpreter qualification

Technical topic: translator/interpreter qualification. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-013`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"translator/interpreter qualification","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — confidentiality and data handling

Technical topic: confidentiality and data handling. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-014`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"confidentiality and data handling","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — review and proofreading

Technical topic: review and proofreading. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-015`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"review and proofreading","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — delivery format

Technical topic: delivery format. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-016`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"delivery format","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## technical — version control

Technical topic: version control. For Localization services, the agent should determine whether this topic is mandatory, conditional or irrelevant to the customer’s exact use. It should collect an objective value, range, class, document reference or explicit unknown—not invent a specification. The answer can affect supplier routing, compatibility, safety, approvals, delivery, installation, total cost or acceptance. Conflicts with drawings, certificates or client specifications must be surfaced and escalated.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-technical-technical_requirement-017`
- Type: `technical_requirement`
- Confidence: `0.88`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"topic":"version control","capture_mode":"value_range_class_document_or_unknown","no_design_calculation":true,"conflict_behavior":"hold_and_escalate"}`

## brands_manufacturers — registered legal translator

registered legal translator is a supplier-market role or example for Localization services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-brands_manufacturers-brand_market_example-001`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"registered legal translator","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — professional translation company

professional translation company is a supplier-market role or example for Localization services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-brands_manufacturers-brand_market_example-002`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"professional translation company","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — specialist technical translator

specialist technical translator is a supplier-market role or example for Localization services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-brands_manufacturers-brand_market_example-003`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"specialist technical translator","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — localization agency

localization agency is a supplier-market role or example for Localization services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-brands_manufacturers-brand_market_example-004`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"localization agency","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — conference-interpreting provider

conference-interpreting provider is a supplier-market role or example for Localization services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-brands_manufacturers-brand_market_example-005`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"conference-interpreting provider","endorsement":false,"live_verification_required":true}`

## brands_manufacturers — linguistic QA provider

linguistic QA provider is a supplier-market role or example for Localization services; it is not an endorsement, approved-vendor declaration or proof of current authorization. Runtime matching must verify the exact legal entity, trade licence, manufacturer authorization where claimed, live certificates, relevant product/service scope, UAE support capability, warranty, references and current availability before presenting the supplier as eligible.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-brands_manufacturers-brand_market_example-006`
- Type: `brand_market_example`
- Confidence: `0.7`
- Status: `draft`
- Review after: `2027-01-31`
- Structured data: `{"market_role":"linguistic QA provider","endorsement":false,"live_verification_required":true}`

## supplier_ecosystem — translator

Supplier type: translator. In Localization services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_ecosystem-supplier_type-001`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"translator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — translator

Eligibility gate 1 for a translator responding to Localization services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_eligibility-eligibility_rule-001`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"translator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — legal translator

Supplier type: legal translator. In Localization services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_ecosystem-supplier_type-002`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"legal translator","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — legal translator

Eligibility gate 2 for a legal translator responding to Localization services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_eligibility-eligibility_rule-002`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"legal translator","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — interpreter

Supplier type: interpreter. In Localization services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_ecosystem-supplier_type-003`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"interpreter","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — interpreter

Eligibility gate 3 for a interpreter responding to Localization services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_eligibility-eligibility_rule-003`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"interpreter","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — localization engineer

Supplier type: localization engineer. In Localization services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_ecosystem-supplier_type-004`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"localization engineer","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — localization engineer

Eligibility gate 4 for a localization engineer responding to Localization services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_eligibility-eligibility_rule-004`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"localization engineer","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — reviewer/proofreader

Supplier type: reviewer/proofreader. In Localization services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_ecosystem-supplier_type-005`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"reviewer/proofreader","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — reviewer/proofreader

Eligibility gate 5 for a reviewer/proofreader responding to Localization services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_eligibility-eligibility_rule-005`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"reviewer/proofreader","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — DTP specialist

Supplier type: DTP specialist. In Localization services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_ecosystem-supplier_type-006`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"DTP specialist","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — DTP specialist

Eligibility gate 6 for a DTP specialist responding to Localization services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_eligibility-eligibility_rule-006`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"DTP specialist","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — equipment provider

Supplier type: equipment provider. In Localization services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_ecosystem-supplier_type-007`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"equipment provider","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — equipment provider

Eligibility gate 7 for a equipment provider responding to Localization services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_eligibility-eligibility_rule-007`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"equipment provider","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## supplier_ecosystem — project manager

Supplier type: project manager. In Localization services, this supplier may cover only part of the value chain. The platform should capture whether it manufactures, imports, distributes, designs, installs, operates, maintains, certifies or subcontracts; the geographic coverage; capacity; response SLA; relevant licences; authorizations; insurance; qualified personnel; references; documents and exclusions. Matching must be capability-based, not name-based.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_ecosystem-supplier_type-008`
- Type: `supplier_type`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"supplier_type":"project manager","capability_fields":["role","coverage","capacity","licence","authorization","insurance","personnel","references","documents"]}`

## supplier_eligibility — Eligibility gate — project manager

Eligibility gate 8 for a project manager responding to Localization services: verify legal registration and scope, relevant licence or accreditation where applicable, capability evidence, authorization claims, jurisdiction/service coverage, competent personnel, current certificates, insurance, reference projects, response capacity and absence of critical compliance flags. A missing mandatory item blocks automatic dispatch or award and creates a documented escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-supplier_eligibility-eligibility_rule-008`
- Type: `eligibility_rule`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"supplier_type":"project manager","mandatory_checks":["legal_entity","licence_scope","capability","coverage","personnel","certificates","insurance","references","capacity"],"failure_action":"block_and_escalate"}`

## quotation — language pair/locale

Quotation requirement: language pair/locale. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-001`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"language_pair_locale","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — purpose/certification

Quotation requirement: purpose/certification. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-002`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"purpose_certification","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — volume/files

Quotation requirement: volume/files. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-003`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"volume_files","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — subject expertise

Quotation requirement: subject expertise. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-004`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"subject_expertise","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — terminology/style

Quotation requirement: terminology/style. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-005`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"terminology_style","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — format/DTP

Quotation requirement: format/DTP. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-006`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"format_dtp","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — interpreting logistics

Quotation requirement: interpreting logistics. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-007`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"interpreting_logistics","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — confidentiality

Quotation requirement: confidentiality. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-008`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"confidentiality","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — QA/revision

Quotation requirement: QA/revision. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-009`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"qa_revision","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## quotation — delivery/deadline

Quotation requirement: delivery/deadline. Every supplier response for Localization services should state this item on the same normalized basis. The platform must distinguish included, excluded, assumed, optional and not-applicable items; capture deviations; require validity and lead time where relevant; and prevent a lower price from appearing superior when it omits scope, evidence, installation, testing, logistics, warranty or support.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-quotation-quotation_requirement-010`
- Type: `quotation_requirement`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"quotation_field":"delivery_deadline","response_states":["included","excluded","assumed","optional","not_applicable"],"deviation_disclosure":true}`

## documents — source files

Document: source files. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-001`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"source_files","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — word/page count

Document: word/page count. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-002`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"word_page_count","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — language/locale matrix

Document: language/locale matrix. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-003`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"language_locale_matrix","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — certification requirement

Document: certification requirement. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-004`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"certification_requirement","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — terminology/glossary

Document: terminology/glossary. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is normally required before supplier dispatch when relevant. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-005`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"terminology_glossary","mandatory_default":true,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — style guide

Document: style guide. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-006`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"style_guide","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — reference translation

Document: reference translation. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-007`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"reference_translation","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — layout sample

Document: layout sample. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-008`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"layout_sample","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — event agenda

Document: event agenda. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-009`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"event_agenda","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — speaker list

Document: speaker list. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-010`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"speaker_list","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — interpreting equipment plan

Document: interpreting equipment plan. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-011`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"interpreting_equipment_plan","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — NDA/data requirement

Document: NDA/data requirement. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-012`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"nda_data_requirement","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — QA checklist

Document: QA checklist. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-013`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"qa_checklist","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## documents — delivery/version schedule

Document: delivery/version schedule. For Localization services, the document may define, evidence or verify scope, technical compliance, authority status, commercial basis, safety, installation or acceptance. The agent should identify the current revision, issuer, date, applicability, signatures/approvals, referenced items and conflicts. It is conditional and should be requested when the related scope or risk is active. Original customer identity must be redacted before supplier sharing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-documents-document_requirement-014`
- Type: `document_requirement`
- Confidence: `0.86`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"document_type":"delivery_version_schedule","mandatory_default":false,"revision_control":true,"redaction_required_before_supplier_share":true}`

## uae_regulations — Registration of Legal Translator

Source activation for Localization services: Registration of Legal Translator (UAE Ministry of Justice). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current registration, language, qualification, renewal and professional requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-uae_regulations-authority_source-001`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR
- Structured data: `{"source_id":"UAE-MOJ-TRANSLATOR","publisher":"UAE Ministry of Justice","url":"https://www.moj.gov.ae/en/services/services-categories/general/registration-of-legal-translator-a9314f86.aspx","source_type":"government_legal_profession_service","live_verification":true}`

## uae_regulations — Document Attestation Services

Source activation for Localization services: Document Attestation Services (UAE Ministry of Foreign Affairs). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify document origin, destination, legalization chain and current service requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-uae_regulations-authority_source-002`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOFA-ATTESTATION
- Structured data: `{"source_id":"UAE-MOFA-ATTESTATION","publisher":"UAE Ministry of Foreign Affairs","url":"https://www.mofa.gov.ae/en/services/attestation","source_type":"government_attestation_service","live_verification":true}`

## uae_regulations — Federal Decree-Law No. 45 of 2021 on Protection of Personal Data

Source activation for Localization services: Federal Decree-Law No. 45 of 2021 on Protection of Personal Data (UAE Legislation). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Legal interpretation and current implementing decisions require counsel.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-uae_regulations-authority_source-003`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-PDPL-45-2021
- Structured data: `{"source_id":"UAE-PDPL-45-2021","publisher":"UAE Legislation","url":"https://uaelegislation.gov.ae/en/legislations/1972","source_type":"federal_law","live_verification":true}`

## uae_regulations — Consumer Protection Legislation and Guidance

Source activation for Localization services: Consumer Protection Legislation and Guidance (UAE Ministry of Economy and Tourism). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current consumer obligations, pricing, warranty, recall and complaint procedures.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-uae_regulations-authority_source-004`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-CONSUMER-PROTECTION
- Structured data: `{"source_id":"UAE-CONSUMER-PROTECTION","publisher":"UAE Ministry of Economy and Tourism","url":"https://www.moet.gov.ae/en/laws","source_type":"government_legislation_portal","live_verification":true}`

## uae_regulations — ISO Standards Catalogue

Source activation for Localization services: ISO Standards Catalogue (International Organization for Standardization). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Do not reproduce paid standards; use licensed current editions and approved summaries.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-uae_regulations-authority_source-005`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: ISO-STANDARDS
- Structured data: `{"source_id":"ISO-STANDARDS","publisher":"International Organization for Standardization","url":"https://www.iso.org/standards.html","source_type":"paid_standard_reference","live_verification":true}`

## uae_regulations — UAE Legislation Portal

Source activation for Localization services: UAE Legislation Portal (UAE Government). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Use the current consolidated legislation and verify amendments and implementing decisions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-uae_regulations-authority_source-006`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-LEGISLATION
- Structured data: `{"source_id":"UAE-LEGISLATION","publisher":"UAE Government","url":"https://uaelegislation.gov.ae/en","source_type":"official_legislation_portal","live_verification":true}`

## uae_regulations — Registration of Legal Translator

Source activation for Localization services: Registration of Legal Translator (UAE Ministry of Justice). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify current registration, language, qualification, renewal and professional requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-uae_regulations-authority_source-007`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR
- Structured data: `{"source_id":"UAE-MOJ-TRANSLATOR","publisher":"UAE Ministry of Justice","url":"https://www.moj.gov.ae/en/services/services-categories/general/registration-of-legal-translator-a9314f86.aspx","source_type":"government_legal_profession_service","live_verification":true}`

## uae_regulations — Document Attestation Services

Source activation for Localization services: Document Attestation Services (UAE Ministry of Foreign Affairs). This source is relevant as a regulatory, authority, conformity, professional or standards reference. The runtime must verify the current version, jurisdiction and applicability before relying on it. The corpus stores a source pointer and operational summary, not a substitute for licensed standards or professional interpretation. Verify document origin, destination, legalization chain and current service requirements.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-uae_regulations-authority_source-008`
- Type: `authority_source`
- Confidence: `0.94`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOFA-ATTESTATION
- Structured data: `{"source_id":"UAE-MOFA-ATTESTATION","publisher":"UAE Ministry of Foreign Affairs","url":"https://www.mofa.gov.ae/en/services/attestation","source_type":"government_attestation_service","live_verification":true}`

## inquiry_qualification — Language/Service

Ask: What source/target languages, locale and exact service are required? Arabic: يرجى توضيح language/service بالنسبة إلى خدمات التوطين اللغوي. Reason: language/service is required to make Localization services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-001`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-domain_1","question_en":"What source/target languages, locale and exact service are required?","question_ar":"يرجى توضيح language/service بالنسبة إلى خدمات التوطين اللغوي.","internal_label_en":"language/service","internal_label_ar":"متطلب خدمات التوطين اللغوي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_1","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":10,"is_common_question":false}`

## inquiry_qualification — Purpose/Subject

Ask: What is the document/content/event purpose, audience and subject matter? Arabic: يرجى توضيح purpose/subject بالنسبة إلى خدمات التوطين اللغوي. Reason: purpose/subject is required to make Localization services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-002`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-domain_2","question_en":"What is the document/content/event purpose, audience and subject matter?","question_ar":"يرجى توضيح purpose/subject بالنسبة إلى خدمات التوطين اللغوي.","internal_label_en":"purpose/subject","internal_label_ar":"متطلب خدمات التوطين اللغوي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_2","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":20,"is_common_question":false}`

## inquiry_qualification — Certification

Ask: Is legal certification, attestation, sworn/legal translator status or authority acceptance required? Arabic: يرجى توضيح certification بالنسبة إلى خدمات التوطين اللغوي. Reason: certification is required to make Localization services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-003`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-domain_3","question_en":"Is legal certification, attestation, sworn/legal translator status or authority acceptance required?","question_ar":"يرجى توضيح certification بالنسبة إلى خدمات التوطين اللغوي.","internal_label_en":"certification","internal_label_ar":"متطلب خدمات التوطين اللغوي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_3","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":30,"is_common_question":false}`

## inquiry_qualification — Volume/Format

Ask: What files, word/page/minute volume, format, layout and version-control requirements apply? Arabic: يرجى توضيح volume/format بالنسبة إلى خدمات التوطين اللغوي. Reason: volume/format is required to make Localization services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-004`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-domain_4","question_en":"What files, word/page/minute volume, format, layout and version-control requirements apply?","question_ar":"يرجى توضيح volume/format بالنسبة إلى خدمات التوطين اللغوي.","internal_label_en":"volume/format","internal_label_ar":"متطلب خدمات التوطين اللغوي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_4","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":40,"is_common_question":false}`

## inquiry_qualification — Terminology/Style

Ask: What terminology, style guide, references, translation memory and subject expertise are required? Arabic: يرجى توضيح terminology/style بالنسبة إلى خدمات التوطين اللغوي. Reason: terminology/style is required to make Localization services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-005`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-domain_5","question_en":"What terminology, style guide, references, translation memory and subject expertise are required?","question_ar":"يرجى توضيح terminology/style بالنسبة إلى خدمات التوطين اللغوي.","internal_label_en":"terminology/style","internal_label_ar":"متطلب خدمات التوطين اللغوي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_5","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":50,"is_common_question":false}`

## inquiry_qualification — Interpreting Logistics

Ask: For interpretation, what mode, dates, venue, speakers, booths/equipment and recording needs apply? Arabic: يرجى توضيح interpreting logistics بالنسبة إلى خدمات التوطين اللغوي. Reason: interpreting logistics is required to make Localization services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-006`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-domain_6","question_en":"For interpretation, what mode, dates, venue, speakers, booths/equipment and recording needs apply?","question_ar":"يرجى توضيح interpreting logistics بالنسبة إلى خدمات التوطين اللغوي.","internal_label_en":"interpreting logistics","internal_label_ar":"متطلب خدمات التوطين اللغوي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_6","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":60,"is_common_question":false}`

## inquiry_qualification — Confidentiality/Qa

Ask: What confidentiality, QA, proofreading, revision, delivery and acceptance terms apply? Arabic: يرجى توضيح confidentiality/QA بالنسبة إلى خدمات التوطين اللغوي. Reason: confidentiality/QA is required to make Localization services quote-ready and comparable. The answer affects subcategory-specific qualification. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-007`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-domain_7","question_en":"What confidentiality, QA, proofreading, revision, delivery and acceptance terms apply?","question_ar":"يرجى توضيح confidentiality/QA بالنسبة إلى خدمات التوطين اللغوي.","internal_label_en":"confidentiality/QA","internal_label_ar":"متطلب خدمات التوطين اللغوي","why_it_matters":"Required for subcategory-specific qualification and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["subcategory-specific qualification"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"domain_7","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":70,"is_common_question":false}`

## inquiry_qualification — Project Emirate

Ask: Which emirate and exact project or delivery location apply? Arabic: يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة. Reason: project emirate is required to make Localization services quote-ready and comparable. The answer affects routing, authority and logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-008`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-project_emirate","question_en":"Which emirate and exact project or delivery location apply?","question_ar":"يرجى تحديد الإمارة والمشروع أو موقع التسليم بدقة.","internal_label_en":"project emirate","internal_label_ar":"إمارة المشروع","why_it_matters":"Required for routing, authority and logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing, authority and logistics"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"project_emirate","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":80,"is_common_question":true}`

## inquiry_qualification — Exact Requirement

Ask: What exact product, service or outcome is required? Arabic: ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟ Reason: exact requirement is required to make Localization services quote-ready and comparable. The answer affects routing and scope. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-009`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-exact_requirement","question_en":"What exact product, service or outcome is required?","question_ar":"ما المنتج أو الخدمة أو النتيجة المطلوبة بالتحديد؟","internal_label_en":"exact requirement","internal_label_ar":"المتطلب الدقيق","why_it_matters":"Required for routing and scope and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["routing and scope"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"exact_requirement","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":90,"is_common_question":true}`

## inquiry_qualification — Intended Use

Ask: What is the intended use, user and operating context? Arabic: ما الاستخدام المقصود والمستخدم وسياق التشغيل؟ Reason: intended use is required to make Localization services quote-ready and comparable. The answer affects technical suitability. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-010`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-intended_use","question_en":"What is the intended use, user and operating context?","question_ar":"ما الاستخدام المقصود والمستخدم وسياق التشغيل؟","internal_label_en":"intended use","internal_label_ar":"الاستخدام المقصود","why_it_matters":"Required for technical suitability and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["technical suitability"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"intended_use","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":100,"is_common_question":true}`

## inquiry_qualification — Quantity

Ask: What quantity is required? Arabic: ما الكمية المطلوبة؟ Reason: quantity is required to make Localization services quote-ready and comparable. The answer affects commercial comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-011`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-quantity","question_en":"What quantity is required?","question_ar":"ما الكمية المطلوبة؟","internal_label_en":"quantity","internal_label_ar":"الكمية","why_it_matters":"Required for commercial comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial comparison"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"quantity","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":110,"is_common_question":true}`

## inquiry_qualification — Unit Of Measure

Ask: What unit of measure should suppliers quote against? Arabic: ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟ Reason: unit of measure is required to make Localization services quote-ready and comparable. The answer affects commercial normalization. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-012`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-unit_of_measure","question_en":"What unit of measure should suppliers quote against?","question_ar":"ما وحدة القياس التي يجب أن يستخدمها الموردون في العرض؟","internal_label_en":"unit of measure","internal_label_ar":"وحدة القياس","why_it_matters":"Required for commercial normalization and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["commercial normalization"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"unit_of_measure","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":120,"is_common_question":true}`

## inquiry_qualification — Delivery Location

Ask: What is the delivery or service location? Arabic: ما موقع التسليم أو تنفيذ الخدمة؟ Reason: delivery location is required to make Localization services quote-ready and comparable. The answer affects logistics. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-013`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-delivery_location","question_en":"What is the delivery or service location?","question_ar":"ما موقع التسليم أو تنفيذ الخدمة؟","internal_label_en":"delivery location","internal_label_ar":"موقع التسليم","why_it_matters":"Required for logistics and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["logistics"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"delivery_location","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":130,"is_common_question":true}`

## inquiry_qualification — Project Stage

Ask: Is this a budget request, design-stage inquiry, tender or approved procurement? Arabic: هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟ Reason: project stage is required to make Localization services quote-ready and comparable. The answer affects scope certainty. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-014`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-project_stage","question_en":"Is this a budget request, design-stage inquiry, tender or approved procurement?","question_ar":"هل الطلب للميزانية أم مرحلة التصميم أم مناقصة أم شراء معتمد؟","internal_label_en":"project stage","internal_label_ar":"مرحلة المشروع","why_it_matters":"Required for scope certainty and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope certainty"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"project_stage","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":140,"is_common_question":true}`

## inquiry_qualification — Scope Boundary

Ask: Is the scope supply only, service only, installation, maintenance or turnkey? Arabic: هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟ Reason: scope boundary is required to make Localization services quote-ready and comparable. The answer affects scope comparison. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-015`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-scope_boundary","question_en":"Is the scope supply only, service only, installation, maintenance or turnkey?","question_ar":"هل النطاق توريد فقط أم خدمة أم تركيب أم صيانة أم تسليم متكامل؟","internal_label_en":"scope boundary","internal_label_ar":"حدود النطاق","why_it_matters":"Required for scope comparison and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["scope comparison"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"scope_boundary","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":150,"is_common_question":true}`

## inquiry_qualification — Budget Basis

Ask: Is there a budget range, pricing format or commercial ceiling? Arabic: هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟ Reason: budget basis is required to make Localization services quote-ready and comparable. The answer affects commercial planning. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-016`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-budget_basis","question_en":"Is there a budget range, pricing format or commercial ceiling?","question_ar":"هل توجد ميزانية أو صيغة تسعير أو سقف تجاري محدد؟","internal_label_en":"budget basis","internal_label_ar":"أساس الميزانية","why_it_matters":"Required for commercial planning and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["commercial planning"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"budget_basis","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":160,"is_common_question":true}`

## inquiry_qualification — Required Delivery Date

Ask: When is delivery, mobilization or completion required? Arabic: متى يلزم التسليم أو بدء العمل أو الإنجاز؟ Reason: required delivery date is required to make Localization services quote-ready and comparable. The answer affects schedule. Expected answer type: text or structured selection as configured. This is mandatory and blocks supplier dispatch when absent.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-017`
- Type: `qualification_question`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-required_delivery_date","question_en":"When is delivery, mobilization or completion required?","question_ar":"متى يلزم التسليم أو بدء العمل أو الإنجاز؟","internal_label_en":"required delivery date","internal_label_ar":"تاريخ التسليم المطلوب","why_it_matters":"Required for schedule and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":true,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"block_dispatch_and_ask","impact":["schedule"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"required_delivery_date","confidence_contribution":0.035,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":170,"is_common_question":true}`

## inquiry_qualification — Governing Documents

Ask: Which drawings, specifications, schedules, BOQ or client standards govern? Arabic: ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟ Reason: governing documents is required to make Localization services quote-ready and comparable. The answer affects technical basis. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-018`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-governing_documents","question_en":"Which drawings, specifications, schedules, BOQ or client standards govern?","question_ar":"ما الرسومات أو المواصفات أو الجداول أو جداول الكميات أو معايير العميل الحاكمة؟","internal_label_en":"governing documents","internal_label_ar":"المستندات الحاكمة","why_it_matters":"Required for technical basis and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["technical basis"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"governing_documents","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":180,"is_common_question":true}`

## inquiry_qualification — Existing Condition

Ask: Is there an existing asset, system, site condition or previous supplier that must be considered? Arabic: هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟ Reason: existing condition is required to make Localization services quote-ready and comparable. The answer affects compatibility. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-019`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-existing_condition","question_en":"Is there an existing asset, system, site condition or previous supplier that must be considered?","question_ar":"هل توجد أصول أو أنظمة أو ظروف موقع أو مورد سابق يجب مراعاته؟","internal_label_en":"existing condition","internal_label_ar":"الحالة القائمة","why_it_matters":"Required for compatibility and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compatibility"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"existing_condition","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":190,"is_common_question":true}`

## inquiry_qualification — Installation Scope

Ask: Is installation, testing, commissioning or training included? Arabic: هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟ Reason: installation scope is required to make Localization services quote-ready and comparable. The answer affects scope and price. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-020`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-installation_scope","question_en":"Is installation, testing, commissioning or training included?","question_ar":"هل يشمل النطاق التركيب والاختبار والتشغيل أو التدريب؟","internal_label_en":"installation scope","internal_label_ar":"نطاق التركيب","why_it_matters":"Required for scope and price and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["scope and price"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"installation_scope","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":200,"is_common_question":true}`

## inquiry_qualification — Site Access

Ask: What access, working-hour, permit, lifting, storage or security constraints apply? Arabic: ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟ Reason: site access is required to make Localization services quote-ready and comparable. The answer affects execution. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-021`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-site_access","question_en":"What access, working-hour, permit, lifting, storage or security constraints apply?","question_ar":"ما قيود الوصول وساعات العمل والتصاريح والرفع والتخزين والأمن؟","internal_label_en":"site access","internal_label_ar":"الوصول إلى الموقع","why_it_matters":"Required for execution and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["execution"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"site_access","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":210,"is_common_question":true}`

## inquiry_qualification — Utilities And Interfaces

Ask: What utilities, interfaces, existing systems or connection points must be matched? Arabic: ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟ Reason: utilities and interfaces is required to make Localization services quote-ready and comparable. The answer affects integration. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-022`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-utilities_interfaces","question_en":"What utilities, interfaces, existing systems or connection points must be matched?","question_ar":"ما الخدمات أو الواجهات أو الأنظمة القائمة أو نقاط الاتصال المطلوب مطابقتها؟","internal_label_en":"utilities and interfaces","internal_label_ar":"الخدمات والواجهات","why_it_matters":"Required for integration and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["integration"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"utilities_interfaces","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":220,"is_common_question":true}`

## inquiry_qualification — Adopted Standards

Ask: Which codes, standards, client specifications or performance classes are adopted? Arabic: ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟ Reason: adopted standards is required to make Localization services quote-ready and comparable. The answer affects compliance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-023`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-adopted_standards","question_en":"Which codes, standards, client specifications or performance classes are adopted?","question_ar":"ما الأكواد أو المعايير أو مواصفات العميل أو فئات الأداء المعتمدة؟","internal_label_en":"adopted standards","internal_label_ar":"المعايير المعتمدة","why_it_matters":"Required for compliance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["compliance"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"adopted_standards","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":230,"is_common_question":true}`

## inquiry_qualification — Authority Requirements

Ask: Which authority, licence, permit, registration or approval requirements apply? Arabic: ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟ Reason: authority requirements is required to make Localization services quote-ready and comparable. The answer affects regulatory activation. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-024`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-authority_requirements","question_en":"Which authority, licence, permit, registration or approval requirements apply?","question_ar":"ما متطلبات الجهات المختصة أو الترخيص أو التصريح أو التسجيل أو الموافقة؟","internal_label_en":"authority requirements","internal_label_ar":"متطلبات الجهات المختصة","why_it_matters":"Required for regulatory activation and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["regulatory activation"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"authority_requirements","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":240,"is_common_question":true}`

## inquiry_qualification — Brand Policy

Ask: Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based? Arabic: هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟ Reason: brand policy is required to make Localization services quote-ready and comparable. The answer affects availability and approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-025`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-brand_policy","question_en":"Is a named brand mandatory, are approved equivalents allowed, or is the requirement performance-based?","question_ar":"هل توجد علامة محددة أم يسمح ببدائل معتمدة أم المتطلب قائم على الأداء؟","internal_label_en":"brand policy","internal_label_ar":"سياسة العلامة التجارية","why_it_matters":"Required for availability and approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["availability and approval"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"brand_policy","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":250,"is_common_question":true}`

## inquiry_qualification — Samples And Mock-Ups

Ask: Are samples, prototypes, trials, demonstrations or mock-ups required before award? Arabic: هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟ Reason: samples and mock-ups is required to make Localization services quote-ready and comparable. The answer affects approval. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-026`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-samples_mockups","question_en":"Are samples, prototypes, trials, demonstrations or mock-ups required before award?","question_ar":"هل تلزم عينات أو نماذج أولية أو تجارب أو عروض قبل الترسية؟","internal_label_en":"samples and mock-ups","internal_label_ar":"العينات والنماذج","why_it_matters":"Required for approval and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["approval"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"samples_mockups","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":260,"is_common_question":true}`

## inquiry_qualification — Testing And Inspection

Ask: What testing, inspection, witness, certification or acceptance evidence is required? Arabic: ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟ Reason: testing and inspection is required to make Localization services quote-ready and comparable. The answer affects quality assurance. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-027`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-testing_inspection","question_en":"What testing, inspection, witness, certification or acceptance evidence is required?","question_ar":"ما الاختبارات أو التفتيش أو الشهادة أو أدلة القبول المطلوبة؟","internal_label_en":"testing and inspection","internal_label_ar":"الاختبار والتفتيش","why_it_matters":"Required for quality assurance and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["quality assurance"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"testing_inspection","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":270,"is_common_question":true}`

## inquiry_qualification — Warranty

Ask: What warranty period and defect-response obligations are required? Arabic: ما مدة الضمان والتزامات الاستجابة للعيوب؟ Reason: warranty is required to make Localization services quote-ready and comparable. The answer affects lifecycle. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-028`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-warranty","question_en":"What warranty period and defect-response obligations are required?","question_ar":"ما مدة الضمان والتزامات الاستجابة للعيوب؟","internal_label_en":"warranty","internal_label_ar":"الضمان","why_it_matters":"Required for lifecycle and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"warranty","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":280,"is_common_question":true}`

## inquiry_qualification — Maintenance

Ask: Is preventive maintenance, consumables, spares or support required? Arabic: هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟ Reason: maintenance is required to make Localization services quote-ready and comparable. The answer affects lifecycle cost. Expected answer type: text or structured selection as configured. This is conditional; if unknown, the supplier brief must state the assumption or exclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-qualification_question-029`
- Type: `qualification_question`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"question_id":"q-localization-services-maintenance","question_en":"Is preventive maintenance, consumables, spares or support required?","question_ar":"هل تلزم صيانة وقائية أو مواد استهلاكية أو قطع غيار أو دعم؟","internal_label_en":"maintenance","internal_label_ar":"الصيانة","why_it_matters":"Required for lifecycle cost and comparable supplier responses.","expected_answer_type":"text","allowed_values":null,"unit":null,"mandatory":false,"conditions":[],"depends_on":[],"validation_rules":[],"missing_answer_behavior":"record_unknown_and_add_quote_assumption","impact":["lifecycle cost"],"regulatory_trigger":null,"documents_that_may_answer":["source files","word/page count","language/locale matrix"],"supplier_facing_field":"maintenance","confidence_contribution":0.018,"escalation_condition":"Escalate when the answer conflicts with an attachment or requires professional/authority interpretation.","order":290,"is_common_question":true}`

## inquiry_qualification — Ask when domain 1 is missing

When domain_1 is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-001`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-domain_1","priority":1000,"when":{"all":[{"field":"domain_1","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-domain_1"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 2 is missing

When domain_2 is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-002`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-domain_2","priority":999,"when":{"all":[{"field":"domain_2","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-domain_2"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 3 is missing

When domain_3 is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-003`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-domain_3","priority":998,"when":{"all":[{"field":"domain_3","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-domain_3"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 4 is missing

When domain_4 is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-004`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-domain_4","priority":997,"when":{"all":[{"field":"domain_4","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-domain_4"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 5 is missing

When domain_5 is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-005`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-domain_5","priority":996,"when":{"all":[{"field":"domain_5","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-domain_5"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 6 is missing

When domain_6 is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-006`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-domain_6","priority":995,"when":{"all":[{"field":"domain_6","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-domain_6"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when domain 7 is missing

When domain_7 is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-007`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-domain_7","priority":994,"when":{"all":[{"field":"domain_7","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-domain_7"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project emirate is missing

When project_emirate is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-008`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-project_emirate","priority":993,"when":{"all":[{"field":"project_emirate","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-project_emirate"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when exact requirement is missing

When exact_requirement is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-009`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-exact_requirement","priority":992,"when":{"all":[{"field":"exact_requirement","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-exact_requirement"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when intended use is missing

When intended_use is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-010`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-intended_use","priority":991,"when":{"all":[{"field":"intended_use","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-intended_use"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when quantity is missing

When quantity is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-011`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-quantity","priority":990,"when":{"all":[{"field":"quantity","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-quantity"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when unit of measure is missing

When unit_of_measure is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-012`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-unit_of_measure","priority":989,"when":{"all":[{"field":"unit_of_measure","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-unit_of_measure"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when delivery location is missing

When delivery_location is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-013`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-delivery_location","priority":988,"when":{"all":[{"field":"delivery_location","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-delivery_location"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when project stage is missing

When project_stage is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-014`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-project_stage","priority":987,"when":{"all":[{"field":"project_stage","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-project_stage"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when scope boundary is missing

When scope_boundary is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-015`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-scope_boundary","priority":986,"when":{"all":[{"field":"scope_boundary","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-scope_boundary"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when budget basis is missing

When budget_basis is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-016`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-budget_basis","priority":985,"when":{"all":[{"field":"budget_basis","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-budget_basis"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when required delivery date is missing

When required_delivery_date is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. Supplier dispatch remains blocked. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-017`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-required_delivery_date","priority":984,"when":{"all":[{"field":"required_delivery_date","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-required_delivery_date"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when governing documents is missing

When governing_documents is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-018`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-governing_documents","priority":983,"when":{"all":[{"field":"governing_documents","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-governing_documents"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when existing condition is missing

When existing_condition is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-019`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-existing_condition","priority":982,"when":{"all":[{"field":"existing_condition","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-existing_condition"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ask when installation scope is missing

When installation_scope is missing for Localization services, ask the linked approved question and set the inquiry to needs_information. If the customer cannot answer, record an explicit supplier assumption. The language model may paraphrase politely but may not skip or invent the answer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-020`
- Type: `decision_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"rule_id":"rule-localization-services-missing-installation_scope","priority":981,"when":{"all":[{"field":"installation_scope","operator":"is_missing"}]},"then":[{"action":"ask_question","question_id":"q-localization-services-installation_scope"},{"action":"set_status","value":"needs_information"}],"requires_human_review":false}`

## inquiry_qualification — Ambiguous Routing

Clarify ambiguous customer language instead of forcing a category. This deterministic rule applies to Localization services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-021`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-localization-services-ambiguous-routing","priority":929,"when":{"any":[{"field":"routing_confidence","operator":"less_than","value":0.82},{"field":"candidate_count","operator":"greater_than","value":1}]},"then":[{"action":"ask_clarifying_question"},{"action":"preserve_candidate_routes"}],"requires_human_review":false}`

## inquiry_qualification — Urgent Delivery

Verify availability and expose urgent-delivery risk. This deterministic rule applies to Localization services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-022`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-localization-services-urgent-delivery","priority":928,"when":{"all":[{"field":"required_delivery_date","operator":"within_days","value":14}]},"then":[{"action":"verify_stock_capacity"},{"action":"request_partial_or_alternative_schedule"},{"action":"mark_schedule_risk"}],"requires_human_review":false}`

## inquiry_qualification — Attachment Conflict

Do not choose between customer text and governing documents silently. This deterministic rule applies to Localization services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-023`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-localization-services-attachment-conflict","priority":927,"when":{"all":[{"field":"attachment_conflict","operator":"equals","value":true}]},"then":[{"action":"hold_dispatch"},{"action":"surface_conflict"},{"action":"request_resolution"}],"requires_human_review":true}`

## inquiry_qualification — Privacy Gate

Block supplier sharing until the supplier-safe package passes redaction. This deterministic rule applies to Localization services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-024`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-localization-services-privacy-gate","priority":926,"when":{"all":[{"field":"supplier_safe_package_passed","operator":"not_equals","value":true}]},"then":[{"action":"block_supplier_dispatch"},{"action":"run_redaction_and_verification"}],"requires_human_review":false}`

## inquiry_qualification — Professional Boundary

Keep regulated or professional judgment outside autonomous authority. This deterministic rule applies to Localization services; its action and reason must be logged. A language model may explain the result but may not override the gate without an authorized review record.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-inquiry_qualification-decision_rule-025`
- Type: `decision_rule`
- Confidence: `0.96`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"rule_id":"rule-localization-services-professional-boundary","priority":925,"when":{"any":[{"field":"requires_design_calculation","operator":"equals","value":true},{"field":"requires_legal_or_medical_interpretation","operator":"equals","value":true},{"field":"authority_acceptance_uncertain","operator":"equals","value":true}]},"then":[{"action":"hold_automatic_decision"},{"action":"escalate_to_qualified_professional"}],"requires_human_review":true}`

## validation — Mandatory Completeness

Validation for Localization services: All mandatory fields must be present or intentionally marked unresolved before dispatch. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-001`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-localization-services-mandatory-completeness","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Quantity And Unit

Validation for Localization services: Quantity must be numeric or clearly bounded and paired with a unit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-002`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-localization-services-quantity-and-unit","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Date Consistency

Validation for Localization services: Required dates must be valid and logically later than inquiry creation unless emergency handling is explicit. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-003`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-localization-services-date-consistency","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Jurisdiction

Validation for Localization services: Project emirate and applicable authority set must resolve to supported values. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-004`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"validation_id":"validation-localization-services-jurisdiction","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Document Revision

Validation for Localization services: Governing documents must have identifiable revisions and conflicts must be blocked. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-005`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-localization-services-document-revision","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Scope Normalization

Validation for Localization services: Supply, installation, testing, commissioning, maintenance and exclusions must be separately stated. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-006`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-localization-services-scope-normalization","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Supplier Eligibility

Validation for Localization services: Every dispatched supplier must pass category-specific eligibility gates. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-007`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"validation_id":"validation-localization-services-supplier-eligibility","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Commercial Comparison

Validation for Localization services: Currency, VAT basis, validity, payment terms and optional items must be normalized. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-008`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-localization-services-commercial-comparison","severity":"error","failure_action":"request_correction","automated":true}`

## validation — Privacy And Redaction

Validation for Localization services: No supplier-visible content may contain customer contact or identifying information before reveal. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-009`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"validation_id":"validation-localization-services-privacy-and-redaction","severity":"critical","failure_action":"block_and_report","automated":true}`

## validation — Professional Boundary

Validation for Localization services: Design, regulated advice and authority acceptance may not be auto-certified by the category agent. A failed validation produces a machine-readable error, identifies the affected field or artifact, blocks the relevant transition when critical, and logs the source/rule version. The system must not repair substantive customer facts by guessing.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-validation-validation_rule-010`
- Type: `validation_rule`
- Confidence: `0.94`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"validation_id":"validation-localization-services-professional-boundary","severity":"critical","failure_action":"block_and_report","automated":true}`

## commercial_pricing — language pair and scarcity

Cost driver: language pair and scarcity. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-001`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"language pair and scarcity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — legal certification

Cost driver: legal certification. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-002`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"legal certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — volume and urgency

Cost driver: volume and urgency. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-003`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"volume and urgency","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — technical specialization

Cost driver: technical specialization. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-004`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"technical specialization","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — layout/localization complexity

Cost driver: layout/localization complexity. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-005`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"layout/localization complexity","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — interpreting equipment and staffing

Cost driver: interpreting equipment and staffing. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-006`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"interpreting equipment and staffing","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — quantity and minimum order

Cost driver: quantity and minimum order. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-007`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"quantity and minimum order","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — material/performance class

Cost driver: material/performance class. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-008`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"material/performance class","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — delivery and access

Cost driver: delivery and access. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-009`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"delivery and access","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## commercial_pricing — testing and certification

Cost driver: testing and certification. This factor can materially change a Localization services quotation. The platform should collect the related field, display it in the comparison and require suppliers to state assumptions. It must not claim an exact current market price without time-stamped transaction or supplier data. Price comparisons must separate base price, options, logistics, installation, testing, recurring cost, taxes and exclusions.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-commercial_pricing-cost_driver-010`
- Type: `cost_driver`
- Confidence: `0.88`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"driver":"testing and certification","exact_price_prediction_allowed":false,"unknown_behavior":"supplier_assumption_required","comparison_components":["base","options","logistics","installation","testing","recurring","tax","exclusions"]}`

## customer_tradeoffs — Lowest Price vs completeness and lifecycle value

Customer trade-off for Localization services: lowest price versus completeness and lifecycle value. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-001`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"lowest price","option_b":"completeness and lifecycle value","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Premium Brand vs approved equivalent and availability

Customer trade-off for Localization services: premium brand versus approved equivalent and availability. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-002`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"premium brand","option_b":"approved equivalent and availability","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Fast Delivery vs technical compliance and testing

Customer trade-off for Localization services: fast delivery versus technical compliance and testing. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-003`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"fast delivery","option_b":"technical compliance and testing","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Standard Product vs custom fit and performance

Customer trade-off for Localization services: standard product versus custom fit and performance. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-004`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"standard product","option_b":"custom fit and performance","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Purchase vs rental or managed service

Customer trade-off for Localization services: purchase versus rental or managed service. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-005`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"purchase","option_b":"rental or managed service","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Local Stock vs OEM traceability and warranty

Customer trade-off for Localization services: local stock versus OEM traceability and warranty. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-006`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"local stock","option_b":"OEM traceability and warranty","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — High Performance vs energy/resource and operating cost

Customer trade-off for Localization services: high performance versus energy/resource and operating cost. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-007`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"high performance","option_b":"energy/resource and operating cost","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Automation vs manual control and resilience

Customer trade-off for Localization services: automation versus manual control and resilience. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-008`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"automation","option_b":"manual control and resilience","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Single Supplier vs specialist multi-vendor scope

Customer trade-off for Localization services: single supplier versus specialist multi-vendor scope. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-009`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"single supplier","option_b":"specialist multi-vendor scope","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## customer_tradeoffs — Short Warranty vs long-term support and spares

Customer trade-off for Localization services: short warranty versus long-term support and spares. The agent should explain the consequence in plain language, collect the customer’s priority, preserve mandatory compliance and let suppliers price clearly separated options. It must not recommend a noncompliant alternative merely because it is cheaper or faster. The selected trade-off should be visible in the final supplier brief and comparison report.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-customer_tradeoffs-tradeoff-010`
- Type: `tradeoff`
- Confidence: `0.84`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"option_a":"short warranty","option_b":"long-term support and spares","mandatory_compliance_preserved":true,"capture_customer_priority":true}`

## risk — wrong language/locale

Risk: wrong language/locale. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-001`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"wrong language/locale","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — unqualified legal translation

Risk: unqualified legal translation. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-002`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"unqualified legal translation","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — meaning or numeric error

Risk: meaning or numeric error. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-003`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"meaning or numeric error","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — confidentiality breach

Risk: confidentiality breach. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-004`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"confidentiality breach","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — format/version mismatch

Risk: format/version mismatch. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-005`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"format/version mismatch","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — insufficient interpreter capacity

Risk: insufficient interpreter capacity. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-006`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"insufficient interpreter capacity","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — scope omission

Risk: scope omission. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-007`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"scope omission","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — certificate expiry

Risk: certificate expiry. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-008`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"certificate expiry","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — delivery failure

Risk: delivery failure. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-009`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"delivery failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## risk — installation interface failure

Risk: installation interface failure. For Localization services, the platform should detect triggers in customer answers, documents, supplier records and quotation deviations; assign severity and owner; request evidence; block supplier dispatch or award when critical; and record mitigation, residual risk and escalation. This is a procurement-control warning, not a substitute for professional risk assessment.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-risk-risk_control-010`
- Type: `risk_control`
- Confidence: `0.9`
- Status: `source_verified`
- Review after: `2026-10-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"risk":"installation interface failure","detect_from":["answers","documents","supplier_records","deviations"],"critical_behavior":"block_and_escalate","record_residual_risk":true}`

## best_practices — Classify The Exact Need Before Questioning

Best practice for Localization services: classify the exact need before questioning. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-best_practices-best_practice-001`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"classify the exact need before questioning","deterministic_workflow_required":true}`

## best_practices — Use Governing Documents And Preserve Revisions

Best practice for Localization services: use governing documents and preserve revisions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-best_practices-best_practice-002`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"use governing documents and preserve revisions","deterministic_workflow_required":true}`

## best_practices — Ask Mandatory Questions Before Optional Details

Best practice for Localization services: ask mandatory questions before optional details. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-best_practices-best_practice-003`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"ask mandatory questions before optional details","deterministic_workflow_required":true}`

## best_practices — Normalize All Supplier Scope And Assumptions

Best practice for Localization services: normalize all supplier scope and assumptions. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-best_practices-best_practice-004`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"normalize all supplier scope and assumptions","deterministic_workflow_required":true}`

## best_practices — Verify Live Licences/Certificates/Authorizations

Best practice for Localization services: verify live licences/certificates/authorizations. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-best_practices-best_practice-005`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"verify live licences/certificates/authorizations","deterministic_workflow_required":true}`

## best_practices — Close With Acceptance, Handover And Lifecycle Support

Best practice for Localization services: close with acceptance, handover and lifecycle support. Apply this practice through deterministic workflow states, not only prompt wording. The system should explain questions in public-friendly language, reuse information already supplied, identify documents that can answer a field, avoid repeated questions, and escalate uncertainty rather than fabricate technical or regulatory facts.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-best_practices-best_practice-006`
- Type: `best_practice`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"practice":"close with acceptance, handover and lifecycle support","deterministic_workflow_required":true}`

## troubleshooting — Customer Uses Vague Terminology

Troubleshooting — customer uses vague terminology: present two or three likely interpretations and ask one simple differentiating question. For Localization services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-troubleshooting-troubleshooting_rule-001`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"customer uses vague terminology","action":"present two or three likely interpretations and ask one simple differentiating question","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Answers Conflict With Attachments

Troubleshooting — answers conflict with attachments: hold dispatch and show the exact conflicting fields/documents. For Localization services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-troubleshooting-troubleshooting_rule-002`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"answers conflict with attachments","action":"hold dispatch and show the exact conflicting fields/documents","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Customer Cannot Provide Technical Value

Troubleshooting — customer cannot provide technical value: request the governing document or permit suppliers to quote an explicit assumption where safe. For Localization services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-troubleshooting-troubleshooting_rule-003`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"customer cannot provide technical value","action":"request the governing document or permit suppliers to quote an explicit assumption where safe","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Supplier Proposes An Alternative

Troubleshooting — supplier proposes an alternative: require a compliance/deviation matrix and approval-risk disclosure. For Localization services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-troubleshooting-troubleshooting_rule-004`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"supplier proposes an alternative","action":"require a compliance/deviation matrix and approval-risk disclosure","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Certificate Or Licence Cannot Be Verified

Troubleshooting — certificate or licence cannot be verified: mark the supplier ineligible until live evidence is confirmed. For Localization services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-troubleshooting-troubleshooting_rule-005`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"certificate or licence cannot be verified","action":"mark the supplier ineligible until live evidence is confirmed","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Urgent Schedule Has No Compliant Stock

Troubleshooting — urgent schedule has no compliant stock: request phased delivery or compliant alternatives and expose schedule risk. For Localization services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-troubleshooting-troubleshooting_rule-006`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"urgent schedule has no compliant stock","action":"request phased delivery or compliant alternatives and expose schedule risk","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Category Overlap Exists

Troubleshooting — category overlap exists: preserve multi-category routing and split the inquiry only when scopes are independently quoteable. For Localization services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-troubleshooting-troubleshooting_rule-007`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"category overlap exists","action":"preserve multi-category routing and split the inquiry only when scopes are independently quoteable","preserve_state":true,"escalate_if_regulated":true}`

## troubleshooting — Model Or Retrieval Service Is Unavailable

Troubleshooting — model or retrieval service is unavailable: continue deterministic questioning and queue noncritical retrieval instead of losing workflow state. For Localization services, the action must be logged, preserve the original customer wording and existing structured answers, and never silently lower compliance or privacy controls. If the issue affects safety, legality, professional judgment, acceptance or supplier identity, route to an authorized reviewer.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-troubleshooting-troubleshooting_rule-008`
- Type: `troubleshooting_rule`
- Confidence: `0.9`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION
- Structured data: `{"symptom":"model or retrieval service is unavailable","action":"continue deterministic questioning and queue noncritical retrieval instead of losing workflow state","preserve_state":true,"escalate_if_regulated":true}`

## scenario_test — Vague Public Request

Scenario test for Localization services: vague public request. Input: I need help with Localization services but I am not sure of the specification. Expected actions: route_candidate, ask_clarification, do_not_invent_specification. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-scenario_test-scenario_test-001`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-localization-services-01","input":{"message":"I need help with Localization services but I am not sure of the specification."},"expected_actions":["route_candidate","ask_clarification","do_not_invent_specification"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Minimum Quote-Ready Request

Scenario test for Localization services: minimum quote-ready request. Input: Customer requests Localization services and provides use, quantity, location and date. Expected actions: extract_fields, ask_remaining_mandatory, build_supplier_safe_brief. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-scenario_test-scenario_test-002`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-localization-services-02","input":{"message":"Customer requests Localization services and provides use, quantity, location and date."},"expected_actions":["extract_fields","ask_remaining_mandatory","build_supplier_safe_brief"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Document Conflict

Scenario test for Localization services: document conflict. Input: Customer text conflicts with a governing attachment. Expected actions: hold_dispatch, surface_conflict, request_resolution. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-scenario_test-scenario_test-003`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-localization-services-03","input":{"message":"Customer text conflicts with a governing attachment."},"expected_actions":["hold_dispatch","surface_conflict","request_resolution"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Supplier Alternative

Scenario test for Localization services: supplier alternative. Input: Supplier proposes a cheaper alternative. Expected actions: request_compliance_matrix, show_deviation, mark_approval_risk. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-scenario_test-scenario_test-004`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-localization-services-04","input":{"message":"Supplier proposes a cheaper alternative."},"expected_actions":["request_compliance_matrix","show_deviation","mark_approval_risk"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Expired Evidence

Scenario test for Localization services: expired evidence. Input: Supplier certificate or authorization is expired or unverifiable. Expected actions: block_supplier, request_live_evidence, log_reason. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-scenario_test-scenario_test-005`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-localization-services-05","input":{"message":"Supplier certificate or authorization is expired or unverifiable."},"expected_actions":["block_supplier","request_live_evidence","log_reason"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Privacy Leak

Scenario test for Localization services: privacy leak. Input: Attachment includes customer name, phone or email. Expected actions: block_dispatch, redact, verify_supplier_safe_package. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-scenario_test-scenario_test-006`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-localization-services-06","input":{"message":"Attachment includes customer name, phone or email."},"expected_actions":["block_dispatch","redact","verify_supplier_safe_package"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## scenario_test — Professional Judgment

Scenario test for Localization services: professional judgment. Input: Customer asks the agent to certify design, legal compliance or authority acceptance. Expected actions: state_boundary, retrieve_source, escalate_to_professional. Pass only when the workflow produces the required structured actions, preserves source/rule version, avoids unsupported claims, and logs any blocked transition or escalation.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-scenario_test-scenario_test-007`
- Type: `scenario_test`
- Confidence: `0.92`
- Status: `reviewed`
- Review after: `2027-01-31`
- Sources: UAE-MOJ-TRANSLATOR, UAE-MOFA-ATTESTATION, UAE-PDPL-45-2021, UAE-CONSUMER-PROTECTION
- Structured data: `{"scenario_id":"scenario-localization-services-07","input":{"message":"Customer asks the agent to certify design, legal compliance or authority acceptance."},"expected_actions":["state_boundary","retrieve_source","escalate_to_professional"],"prohibited":["invent customer fact","bypass privacy gate","claim professional approval"],"pass_condition":"all expected actions present and no prohibited action"}`

## glossary — source language

English term: source language. Arabic operational label: مصطلح source language ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-001`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"source language","term_ar":"مصطلح source language ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — target language

English term: target language. Arabic operational label: مصطلح target language ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-002`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"target language","term_ar":"مصطلح target language ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — locale

English term: locale. Arabic operational label: مصطلح locale ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-003`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"locale","term_ar":"مصطلح locale ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — legal translation

English term: legal translation. Arabic operational label: مصطلح legal translation ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-004`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"legal translation","term_ar":"مصطلح legal translation ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — certified translation

English term: certified translation. Arabic operational label: مصطلح certified translation ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-005`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certified translation","term_ar":"مصطلح certified translation ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — attestation

English term: attestation. Arabic operational label: مصطلح attestation ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-006`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"attestation","term_ar":"مصطلح attestation ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — consecutive interpretation

English term: consecutive interpretation. Arabic operational label: مصطلح consecutive interpretation ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-007`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"consecutive interpretation","term_ar":"مصطلح consecutive interpretation ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — simultaneous interpretation

English term: simultaneous interpretation. Arabic operational label: مصطلح simultaneous interpretation ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-008`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"simultaneous interpretation","term_ar":"مصطلح simultaneous interpretation ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — translation memory

English term: translation memory. Arabic operational label: مصطلح translation memory ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-009`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"translation memory","term_ar":"مصطلح translation memory ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — terminology base

English term: terminology base. Arabic operational label: مصطلح terminology base ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-010`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"terminology base","term_ar":"مصطلح terminology base ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — localization

English term: localization. Arabic operational label: مصطلح localization ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-011`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"localization","term_ar":"مصطلح localization ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — DTP

English term: DTP. Arabic operational label: مصطلح DTP ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-012`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"DTP","term_ar":"مصطلح DTP ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — subtitling

English term: subtitling. Arabic operational label: مصطلح subtitling ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-013`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"subtitling","term_ar":"مصطلح subtitling ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — proofreading

English term: proofreading. Arabic operational label: مصطلح proofreading ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-014`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"proofreading","term_ar":"مصطلح proofreading ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — back translation

English term: back translation. Arabic operational label: مصطلح back translation ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-015`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"back translation","term_ar":"مصطلح back translation ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — NDA

English term: NDA. Arabic operational label: مصطلح NDA ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-016`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"NDA","term_ar":"مصطلح NDA ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — scope of work

English term: scope of work. Arabic operational label: مصطلح scope of work ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-017`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"scope of work","term_ar":"مصطلح scope of work ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — technical submittal

English term: technical submittal. Arabic operational label: مصطلح technical submittal ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-018`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"technical submittal","term_ar":"مصطلح technical submittal ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — compliance matrix

English term: compliance matrix. Arabic operational label: مصطلح compliance matrix ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-019`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"compliance matrix","term_ar":"مصطلح compliance matrix ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — deviation

English term: deviation. Arabic operational label: مصطلح deviation ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-020`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"deviation","term_ar":"مصطلح deviation ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — approved equal

English term: approved equal. Arabic operational label: مصطلح approved equal ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-021`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"approved equal","term_ar":"مصطلح approved equal ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — certificate of conformity

English term: certificate of conformity. Arabic operational label: مصطلح certificate of conformity ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-022`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"certificate of conformity","term_ar":"مصطلح certificate of conformity ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — method statement

English term: method statement. Arabic operational label: مصطلح method statement ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-023`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"method statement","term_ar":"مصطلح method statement ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — inspection and test plan

English term: inspection and test plan. Arabic operational label: مصطلح inspection and test plan ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-024`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"inspection and test plan","term_ar":"مصطلح inspection and test plan ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — warranty

English term: warranty. Arabic operational label: الضمان. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-025`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"warranty","term_ar":"الضمان","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — preventive maintenance

English term: preventive maintenance. Arabic operational label: مصطلح preventive maintenance ضمن خدمات التوطين اللغوي. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-026`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"preventive maintenance","term_ar":"مصطلح preventive maintenance ضمن خدمات التوطين اللغوي","canonical_subcategory":"localization-services","normalization_only":true}`

## glossary — acceptance criteria

English term: acceptance criteria. Arabic operational label: معايير القبول. Use this pair for customer-language normalization, routing and supplier-facing output for Localization services. Preserve the customer’s original wording and map it to the canonical term. A synonym is not proof of an exact model, grade, legal meaning, approval or professional conclusion.

- Record ID: `qd-kb-translation-interpretation-and-localization-localization-services-glossary-bilingual_term-027`
- Type: `bilingual_term`
- Confidence: `0.82`
- Status: `reviewed`
- Review after: `2027-01-31`
- Structured data: `{"term_en":"acceptance criteria","term_ar":"معايير القبول","canonical_subcategory":"localization-services","normalization_only":true}`

