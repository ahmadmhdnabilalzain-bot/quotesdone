# Claude Handoff — Import QD-KB-001 into QuotesDone/Supabase

You are the implementation engineer. Import this package into a staging environment before production.

## Non-negotiable controls

1. Use `construction-civil-and-building-materials` as the stable category key. The founder sequence is 1, while an existing migration comment uses production domain number 16; map by slug, not display number.
2. Validate every line against `_support/knowledge-record-v1.json` and reject malformed rows.
3. Upsert by stable `record_id`, `question_id`, `rule_id`, `validation_id` and `scenario_id`; preserve package version and previous versions.
4. Import `19_source_registry.csv` and `03_taxonomy.json` before knowledge records.
5. Store narrative records in the searchable knowledge table and generate embeddings only for narrative/search modules.
6. Store questions, decision rules and validation rules in deterministic tables. Do not make the language model decide question sequencing, completeness or regulatory activation when a rule exists.
7. Keep `validation_status` unchanged. Do not promote `draft` or `source_verified` records to `approved` without SME review.
8. Do not ingest paid standard text from elsewhere unless QuotesDone holds the necessary licence. This package contains references only.
9. Add runtime checks for dynamic certificate/registry validity. A source-backed narrative is not proof that a certificate remains current.
10. Run all records in `18_scenarios_tests.jsonl` after import and produce a pass/fail report.

## Suggested tables

- `kb_categories`, `kb_subcategories`, `kb_aliases`
- `kb_sources`
- `kb_records`
- `kb_questions`
- `kb_decision_rules`
- `kb_validation_rules`
- `kb_scenario_tests`
- `kb_gap_register`
- `kb_ingestion_runs`

Adapt names to the existing schema, but preserve all fields and source lineage. Use `21_ingestion_manifest.json` for file hashes, row counts and order. `23_all_records.jsonl` is a convenience stream; the numbered module files remain the preferred auditable import path.

## Required output

Return an ingestion report showing inserted, updated, skipped, rejected and duplicate counts by file and subcategory; schema changes; scenario results; unresolved mapping issues; and any code paths that still call OpenRouter despite an applicable deterministic record.
