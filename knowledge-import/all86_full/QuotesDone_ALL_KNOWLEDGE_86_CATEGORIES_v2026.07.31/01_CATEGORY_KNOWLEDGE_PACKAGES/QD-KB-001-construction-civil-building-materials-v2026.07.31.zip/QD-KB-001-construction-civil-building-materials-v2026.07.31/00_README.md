# QuotesDone Knowledge Pack QD-KB-001

**Category:** Construction, Civil & Building Materials  
**Version:** 1.0.0  
**Build date:** 2026-07-31  
**Subcategories:** 17  
**Status:** Production research draft; source-backed but not yet UAE SME certified.

## What this package contains

This package covers every subcategory in the founder's Category 1 taxonomy. `02_category_master.md` is the consolidated human-readable backlog. JSONL files are atomic ingestion records for Claude/Supabase. The package separates narrative retrieval records from deterministic questions, decision rules, validations and tests so the runtime does not need to place the entire corpus into an AI prompt.

## Claude handoff

Give Claude the whole ZIP and start with `24_CLAUDE_INGESTION_PROMPT.md`.

## Required ingestion order

1. `19_source_registry.csv`
2. `03_taxonomy.json`
3. Module JSONL files `04` through `12`
4. `13_decision_rules.jsonl`
5. `14_validation_rules.jsonl`
6. Modules `15` through `18`
7. Run all scenario tests from `18_scenarios_tests.jsonl`
8. Produce an ingestion report and keep the package version/hash.

## Suggested runtime policy

- SQL/rules choose questions, run validations, determine completeness, activate sources and filter suppliers.
- Internal retrieval provides only relevant records by subcategory, field, jurisdiction and inquiry state.
- A small model may parse customer language into approved fields and phrase approved questions.
- A premium external model is used only for low-confidence language, complex documents/images or an explicit escalation.
- Models may not override regulatory, validation or supplier-eligibility rules.

## Important limitations

- No paid standard is reproduced; licensed current editions are required for clause-level use.
- Brand entries are examples, not endorsements or proof of current availability.
- This pack supports inquiry qualification and procurement comparison; it does not perform professional engineering design or issue authority/legal approval.
- Dynamic certificates and registers must be checked at runtime.
- Open issues are listed in `20_gap_register.csv` and `22_QA_report.md`.
