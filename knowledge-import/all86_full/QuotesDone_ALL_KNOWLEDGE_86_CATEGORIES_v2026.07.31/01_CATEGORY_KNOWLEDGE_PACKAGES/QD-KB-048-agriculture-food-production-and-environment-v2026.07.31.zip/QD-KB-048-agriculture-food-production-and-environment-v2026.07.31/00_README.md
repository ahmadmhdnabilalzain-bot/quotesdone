# QuotesDone Category 48 Knowledge Package

**Category:** Agriculture, Food Production & Environment
**Subcategories:** 11
**Status:** production draft; not SME-approved

Use the numbered JSONL files for programmatic ingestion. `02_category_master.md` is a human-audit view and must not be inserted into every model prompt. Deterministic question, decision-rule and validation files reduce model use.
