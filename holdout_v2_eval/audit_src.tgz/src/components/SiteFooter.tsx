import { useTranslations } from 'next-intl';
import { Link } from '@/i18n/routing';
import { Reveal, SpringHover } from '@/components/motion/primitives';
import { BrandMark } from '@/components/BrandMark';

// Live company accounts (verified against Postiz + reachable). Keep in sync if a handle changes.
const SOCIALS = [
  { name: 'Instagram', href: 'https://www.instagram.com/official.quotesdone/', d: 'M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.209 0-4-1.79-4-4 0-2.209 1.79-4 4-4 2.209 0 4 1.79 4 4 0 2.209-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z' },
  { name: 'LinkedIn', href: 'https://www.linkedin.com/company/quotesdone', d: 'M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z' },
  { name: 'X', href: 'https://x.com/QuotesdoneUAE', d: 'M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z' },
  { name: 'Facebook', href: 'https://www.facebook.com/quotesdone.UAE', d: 'M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z' },
];

export function SiteFooter() {
  const t = useTranslations();
  const col = 'font-mono text-[10px] font-semibold uppercase tracking-[0.2em] text-teal-light/75';
  // inline-flex + min-height gives a comfortable mobile hit area (WCAG 2.5.8)
  // without changing the visual rhythm on desktop.
  const link =
    'inline-flex min-h-[26px] items-center text-[14px] text-muted transition-colors duration-200 hover:text-white';
  return (
    <footer className="mt-beat-s border-t border-[var(--line)] pt-14 pb-10 md:mt-beat">
      <div className="container-x">
        <Reveal className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr_1fr] lg:gap-12">
          <div>
            <Link
              href="/"
              aria-label="QuotesDone"
              className="group inline-flex items-center gap-2.5 font-head text-[19px] font-bold tracking-tight text-white"
            >
              <BrandMark className="h-8 w-8 shrink-0 drop-shadow-[0_2px_8px_rgba(20,184,166,.35)] transition-transform duration-300 ease-expo group-hover:rotate-[8deg] group-hover:scale-110" />
              <span>
                Quotes<span className="text-teal">Done</span>
              </span>
            </Link>
            <p className="mt-4 max-w-[34ch] text-pretty text-[14px] leading-relaxed text-muted">
              {t('footer.tagline')}
            </p>
            <div className="mt-6 flex items-center gap-2.5" style={{ direction: 'ltr' }}>
              {SOCIALS.map((s) => (
                <SpringHover key={s.name} className="rounded-full" scale={1.12} lift={-3}>
                  <a
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={s.name}
                    title={s.name}
                    className="grid h-9 w-9 place-items-center rounded-full border border-[var(--line2)] bg-teal-light/[0.03] text-muted transition-colors duration-200 hover:border-teal hover:bg-teal/[0.09] hover:text-teal-light hover:shadow-[0_10px_26px_-12px_rgba(20,184,166,.8)]"
                  >
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true" focusable="false">
                      <path d={s.d} />
                    </svg>
                  </a>
                </SpringHover>
              ))}
            </div>
          </div>
          <div>
            <div className={col}>{t('footer.company')}</div>
            <ul className="mt-3 space-y-1">
              <li><Link className={link} href="/about">{t('footer.about')}</Link></li>
              <li><Link className={link} href="/contact">{t('footer.contact')}</Link></li>
              <li><Link className={link} href="/faq">{t('footer.faq')}</Link></li>
              <li><Link className={link} href="/services">{t('footer.services')}</Link></li>
            </ul>
          </div>
          <div>
            <div className={col}>{t('footer.legal')}</div>
            <ul className="mt-3 space-y-1">
              <li><Link className={link} href="/terms">{t('footer.terms')}</Link></li>
              <li><Link className={link} href="/privacy">{t('footer.privacy')}</Link></li>
              <li><Link className={link} href="/cookie-policy">{t('footer.cookies')}</Link></li>
              <li><Link className={link} href="/refund-policy">{t('footer.refunds')}</Link></li>
            </ul>
          </div>
          <div>
            <div className={col}>{t('footer.more')}</div>
            <ul className="mt-3 space-y-1">
              <li><Link className={link} href="/supplier-agreement">{t('footer.supplier')}</Link></li>
              <li><Link className={link} href="/acceptable-use">{t('footer.aup')}</Link></li>
              <li><Link className={link} href="/disclaimer">{t('footer.disclaimer')}</Link></li>
              <li><Link className={link} href="/complaints">{t('footer.complaints')}</Link></li>
            </ul>
          </div>
        </Reveal>
        <div className="mt-12 border-t border-[var(--line)] pt-6 font-mono text-[11px] leading-relaxed text-faint">
          © {new Date().getFullYear()} QuotesDone Technologies · Dubai DET E-Trader Licence No. 1633275 · {t('footer.rights')}
        </div>
      </div>
    </footer>
  );
}
